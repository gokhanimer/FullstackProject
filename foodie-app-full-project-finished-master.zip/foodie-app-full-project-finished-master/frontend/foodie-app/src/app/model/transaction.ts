export class Transaction{
  transId: string ="";
  dishName: Array<string> =[];
  totalPrice: number = 0;
  paymentMethod: string ="";
  username: string ="";
  date: string ="";
  status: string ="";
  restaurantId: number = 0;

}
