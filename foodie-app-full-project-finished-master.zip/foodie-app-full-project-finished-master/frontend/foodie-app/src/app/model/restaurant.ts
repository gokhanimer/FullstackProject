export class Restaurant{

  restaurantId: number;
  restaurantName: string="";
  category: string ="";
  address: string ="";
  phonenumber: number;
  image: string ="";
  city: string ="";
  approvalStatus: boolean = false;
  username: string="";
  rating : Map<string, number> = new Map<string, number>([["Creation", 0]]);

}
