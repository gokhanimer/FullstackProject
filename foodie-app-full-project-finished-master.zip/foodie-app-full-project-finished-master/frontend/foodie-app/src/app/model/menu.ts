import { Dish } from "./dish";

export class Menu{

  restaurantId : number;

  dishes : Dish[];
}
