export class Userprofile {

  username: string ="";
  password: string ="";
  firstname: string ="";
  lastname: string ="";
  phonenumber: number;
  city: string="";
  address: string="";
  status: string="";

}
