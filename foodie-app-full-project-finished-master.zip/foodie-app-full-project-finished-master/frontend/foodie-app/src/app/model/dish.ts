export class Dish{

  dishName: string="";
  price: number;
  description: string="";
  category: string="";
  availability: string="";
  ingredients: Array<string>;
}
