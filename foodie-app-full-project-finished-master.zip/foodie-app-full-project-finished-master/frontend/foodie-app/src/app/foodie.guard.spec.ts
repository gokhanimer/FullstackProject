import { TestBed } from '@angular/core/testing';

import { FoodieGuard } from './foodie.guard';

describe('FoodieGuard', () => {
  let guard: FoodieGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(FoodieGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
