import { Injectable } from '@angular/core';
import {Router} from "@angular/router";
import {Location} from "@angular/common";

@Injectable({
  providedIn: 'root'
})
export class RouteService {

  constructor(private router: Router, private location: Location) { }

  goToAdminDashboard(){
    this.router.navigate(['admin-dashboard']);
  }
  goToUserDashboard(){
    this.router.navigate(['user-dashboard']);
  }
  goToRestaurantDashboard(){
    this.router.navigate(['restaurant-dashboard'])
  }

  goToLogin(){
    this.router.navigate(['login'])
  }

  goToUserRegister(){
    this.router.navigate(['user-register'])
  }

  goToRestaurantRegister(){
    this.router.navigate(['restaurant-register'])
  }

  goBack(){
    this.location.back();
  }

  goToUserRestaurantView(){
    this.router.navigate(['user-view-restaurant'])
  }

  goToRestaurantView(){
    this.router.navigate(['view-restaurant'])
  }

  goToCart(){
    this.router.navigate(['cart'])
  }

  goToDishesForRestaurant(){
    this.router.navigate(['dishes-view-restaurant']);
  }

  goToOrderView(){
    this.router.navigate(['order-view']);
  }

  navigateToDishEdit(dishName:String, id:number)
  {
    console.log('trying to edit Dish: '+dishName+" on restaurantId: "+id)
    this.router.navigate(['dishesEdit',{ outlets: {editDishOutlet: ['editDish',dishName]}}]);
  }

  navigateToEdit(restaurantId)
  { console.log('trying to edit the restaurant')
    this.router.navigate(['restaurant-dashboard',
      { outlets: { editOutlet: ['edit', restaurantId]}}]);
  }

  goToRestaurantTransactions() {
    this.router.navigate(['restaurant-transactions'])
  }

}
