import { Injectable } from '@angular/core';
import {Userprofile} from "../model/userprofile";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Restaurant} from "../model/restaurant";
import {BehaviorSubject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  public allUsers: Array<Userprofile> = [];
  public allUsersSubject: BehaviorSubject<Array<Userprofile>>;

  constructor(private httpCli: HttpClient) {
    this.getAllUsersFromServer();
    this.allUsersSubject = new BehaviorSubject(this.allUsers);
  }

  registerUser(reguserprofile: Userprofile){
    this.httpCli.post<Userprofile>("http://localhost:9093/user/register/addUser", reguserprofile)
      .subscribe(reguser => {
        console.log(reguser);
      });
    console.log("Success!");
  }

  getAllUsersFromServer(){
    return this.httpCli.get<Userprofile[]>("http://localhost:9093/user/register/viewUsers", {
      headers: new HttpHeaders().set('Access-Control-Allow-Origin', '*')
        .set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
      .subscribe(res => {
        this.allUsers = res;
        this.allUsersSubject.next(this.allUsers);
      })
  }
  getAllUsers(){
    return this.allUsersSubject;

  }


}
