import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {BehaviorSubject, Observable, tap} from "rxjs";
import {Menu} from "../model/menu";
import {Dish} from "../model/dish";

@Injectable({
  providedIn: 'root'
})
export class DishService {

  public allName : Array<string> = [];

  public allDishInCart : Array<Dish> = [];
  public dishCounter: number = 0;
  public showOneDishInCart: Array<Dish> = [];


  public allMenus: Array<Menu> = [];
  public menuSubject: BehaviorSubject<Array<Menu>>;

  constructor(private httpClient : HttpClient) {
    this.getMenuFromServer();
    this.menuSubject = new BehaviorSubject(this.allMenus);

  }

  getMenuFromServer() {
    return this.httpClient.get<Menu[]>("http://localhost:9090/Menu/mongo/viewAllDishes", {
      headers: new HttpHeaders().set('Access-Control-Allow-Origin', '*')
        .set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
      .subscribe(menus => {

        this.allMenus = menus;

        this.menuSubject.next(this.allMenus);
      })
  }

  getAllDishes(){
    return this.menuSubject;
  }


  addMenu(newMenu : Menu){
    this.httpClient.post<Menu>("http://localhost:9090/Menu/mongo/addMenu", newMenu, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
      .subscribe(regres => {
        this.allMenus.push(newMenu);
        this.menuSubject.next(this.allMenus);
        console.log("Success!", this.allMenus);
      });
  }



  addDish(id : number, newDish : Dish): Observable<any>{
    console.log("Adding news", newDish);
    return this.httpClient.post<Dish>(`${"http://localhost:9090/Menu/mongo/addDish"}/${id}`, newDish, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
      .pipe(tap(newdish => {
        console.log("Got news", newdish);
        this.allMenus.forEach(menu=>{
          if(menu.restaurantId=id){
            menu.dishes.push(newDish)
          }
        });
        this.menuSubject.next(this.allMenus);
      }))
  }

  updateDish(id : number, newDish : Dish): Observable<any>{
    console.log("updating new dish: "+ newDish+" on id: "+id);
    return this.httpClient.put<Dish>(`${"http://localhost:9090/Menu/mongo/updateDish"}/${id}`, newDish, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    });}

  deleteDish(id: number, dishName: String): Observable<any> {
    console.log("deleting "+id+" "+dishName)

    return this.httpClient.delete(
      `${"http://localhost:9090/Menu/mongo/deleteDish"}/${id}`,
      { headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`), body: {dishName}}
    );
  }

  deleteMenu(id: number): Observable<any> {
    return this.httpClient.delete(
      `${"http://localhost:9090/Menu/mongo/deleteMenu"}/${id}`,
      { headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)}
    );
  }

  getDishFromServerByRestaurantId(id : number) {
    return this.httpClient.get<Menu>(`${"http://localhost:9090/Menu/mongo/viewDishesByRestaurant"}/${id}`, {
      headers: new HttpHeaders().set('Access-Control-Allow-Origin', '*')
        .set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
  }

  getDishFromServerByCategory(category : string) {
    return this.httpClient.get<Menu[]>(`${"Menu/mongo/viewAllDishesByCategory"}/${category}`, {
      headers: new HttpHeaders().set('Access-Control-Allow-Origin', '*')
        .set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
  }

  getDishFromServerByAvailability(availability : string) {
    return this.httpClient.get<Menu[]>(`${"Menu/mongo/viewAllDishesByAvailability"}/${availability}`, {
      headers: new HttpHeaders().set('Access-Control-Allow-Origin', '*')
        .set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
  }
  //Here is User-frontend

  addDishToCart(dish: Dish){
      this.allDishInCart.push(dish);
  }

  removeDishFromCart(dish: Dish){
    const index = this.allDishInCart.indexOf(dish, 0);
    if (index > -1) {
      this.allDishInCart.splice(index, 1);
    }
  }

  getAllDishFromArrayToCheckout(){
    return this.allDishInCart;
  }

  clearAllDishFromArray(){
    this.showOneDishInCart = [];
    this.allDishInCart = [];
  }

  getAllSingleDishesInCart(){
    this.showOneDishInCart = [...new Set(this.allDishInCart.map(item => item))];
    return this.showOneDishInCart;
  }

}
