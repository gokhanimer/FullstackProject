import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import { Userprofile } from '../model/userprofile';

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

  constructor(private httpCli: HttpClient) {  }

  generateTokenFromServer(userobj : Userprofile) {
    console.log(userobj);
    return this.httpCli.post<Userprofile>("http://localhost:9093/user/login/authUser", userobj); //SOME OTHER CALL HERE
  }

}
