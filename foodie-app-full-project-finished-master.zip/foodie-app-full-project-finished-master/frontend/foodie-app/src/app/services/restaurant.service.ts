import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Restaurant} from "../model/restaurant";
import {BehaviorSubject, Observable, tap} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {


  headers = new HttpHeaders()
    .set('content-type', 'application/json')
    .set('Access-Control-Allow-Origin', '*');

  public allRestaurants: Array<Restaurant> = [];
  public restaurantSubject: BehaviorSubject<Array<Restaurant>>;
  public allRestaurantsByTrue: Array<Restaurant> = [];
  public restaurantByTrueSubject: BehaviorSubject<Array<Restaurant>>;
  public restaurandByFalseSubject: BehaviorSubject<Array<Restaurant>>;

  public restaurantJSON: string;

  private restaurantSource = new BehaviorSubject<string>('');
  restId = this.restaurantSource.asObservable();

  constructor(private httpClient: HttpClient) {
    this.getRestaurantsFromServer();
    this.restaurantSubject = new BehaviorSubject(this.allRestaurants);
    this.getRestaurantsFromServerWithApprovalStatus();
    this.restaurantByTrueSubject = new BehaviorSubject(this.allRestaurantsByTrue);

  }

  changeId(restId: number) {
    this.allRestaurants.forEach(rest => {
      if(rest.restaurantId == restId){
        this.restaurantJSON = JSON.stringify(rest);
        sessionStorage.setItem("restaurant", this.restaurantJSON);
      }
    });
  }

  getRestaurantsFromServer(){
    return this.httpClient.get<Restaurant[]>("http://localhost:9094/restaurant/getRestaurant", {
      headers: new HttpHeaders().set('Access-Control-Allow-Origin', '*')
        .set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
      .subscribe(res => {
        this.allRestaurants = res;
        this.restaurantSubject.next(this.allRestaurants);
      })
  }

  getRestaurantsFromServerWithApprovalStatus() {
    return this.httpClient.get<Restaurant[]>("http://localhost:9094/restaurant/getByApprovalStatus/true", {
      headers: new HttpHeaders().set('Access-Control-Allow-Origin', '*')
        .set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
      .subscribe(res => {
        this.allRestaurantsByTrue = res;
        this.restaurantByTrueSubject.next(this.allRestaurantsByTrue);
      })
  }

  getRestaurants(){
    return this.restaurantSubject;
  }

  getRestaurantById(id) {
    const editRestaurant = this.allRestaurants.find(restaurant => restaurant.restaurantId == id);
    return Object.assign({}, editRestaurant)
  }

  getRestaurantsWhichIsTrue(){
    return this.restaurantByTrueSubject;
  }

  getRestaurantsWhichIsFalse(){
    return this.restaurandByFalseSubject;
  }

  saveRestaurant(restaurant: Restaurant) {
    return this.httpClient.put<Restaurant>("http://localhost:9094/restaurant/update", restaurant)
      .pipe(tap(editRestaurant => {
        const existingRestaurant = this.allRestaurants.find(res => restaurant.restaurantId == res.restaurantId);
        Object.assign(existingRestaurant, editRestaurant);
        this.restaurantSubject.next(this.allRestaurants);
      }))
  }

  registerRestaurant(regRestaurant: Restaurant){
    this.httpClient.post<Restaurant>("http://localhost:9094/restaurant/addRestaurant", regRestaurant, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
      .subscribe(regres => {
        this.allRestaurants.push(regres);
        this.restaurantSubject.next(this.allRestaurants);
        console.log("Success!", this.allRestaurants);
      });
  }

  deleteRestaurant(RestaurantId: number): Observable<any>{
    return this.httpClient.delete(`${"http://localhost:9094/restaurant/deleteRestaurant"}/${RestaurantId}`, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
  }

  updateRestaurantRating(restaurantId: number, newRating: number, userName : String): Observable<any>{

    return this.httpClient.put<{any}>(`${"http://localhost:9094/restaurant/updateRating"}/${restaurantId},${userName},${newRating}`,
      {
        headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
      });}


  getRating(restaurantId: number): Observable<any>{

    return this.httpClient.get<any>(`${"http://localhost:9094/restaurant/getRating"}/${restaurantId}`,
      {
        headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
      });}

  updateRestaurantApprovalStatus(restaurantId: number, newStatus: boolean){
    return this.httpClient.put<{any}>(`${"http://localhost:9094/restaurant/updateApprovalStatus"}/${restaurantId},${newStatus}`, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
  }

}
