import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {BehaviorSubject, Observable} from "rxjs";
import {Transaction} from "../model/transaction";

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  private serviceUrl = 'http://localhost:8383/transaction/viewAllTransactions';

  headers = new HttpHeaders()
    .set('content-type', 'application/json')
    .set('Access-Control-Allow-Origin', '*');

  public allTransactions: Array<Transaction> = [];
  public transactionSubject: BehaviorSubject<Array<Transaction>>;
  public allTransactionsByUsername: Array<Transaction> = [];
  public transactionSubjectByUsername: BehaviorSubject<Array<Transaction>>;

  private transactionSource = new BehaviorSubject<string>('');
  transId = this.transactionSource.asObservable();

  constructor(private httpClient: HttpClient) {
    this.getTransactionsFromServer();
    this.transactionSubject = new BehaviorSubject<Array<Transaction>>(this.allTransactions);
  }

  getTransactions(): Observable<Transaction[]> {
    return this.httpClient.get<Transaction[]>(this.serviceUrl);
  }

  getTransactionsFromServer(){
    return this.httpClient.get<Transaction[]>("http://localhost:8383/transaction/viewAllTransactions", {
      headers: new HttpHeaders().set('Access-Control-Allow-Origin', '*')
        .set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
      .subscribe(res => {
        this.allTransactions = res;
        this.transactionSubject.next(this.allTransactions);
      })
  }

  getAllTransactions(){
    return this.transactionSubject;
  }

  addTransaction(regTransaction: Transaction){
      this.httpClient.post<Transaction>("http://localhost:8383/transaction/addTransaction", regTransaction, {
        headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
      })
        .subscribe(regres => {
          this.allTransactions.push(regres);
          this.transactionSubject.next(this.allTransactions);
          console.log("Success!", this.allTransactions);
        });
    }

  getTransactionsFromServerWithUsername(username: string){
    return this.httpClient.get<Transaction[]>("/viewTransactionByUsername/" + username, {
      headers: new HttpHeaders().set('Access-Control-Allow-Origin', '*')
        .set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
  }

  getTransactionsFromServerByRestaurantId(id : number) : Observable<Transaction[]> {
    return this.httpClient.get<Transaction[]>(`${"http://localhost:8383/transaction/viewTransactionByRestaurantId"}/${id}`, {
      headers: new HttpHeaders().set('Access-Control-Allow-Origin', '*')
        .set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
  }
  deleteTransaction(transId : string) : Observable<any> {
    return this.httpClient.delete(`${"http://localhost:8383/transaction/deleteTransaction"}/${transId}`, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${sessionStorage.getItem('mytoken')}`)
    })
  }

}
