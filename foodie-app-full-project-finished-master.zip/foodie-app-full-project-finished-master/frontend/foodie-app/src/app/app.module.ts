import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MdbAccordionModule } from 'mdb-angular-ui-kit/accordion';
import { MdbCarouselModule } from 'mdb-angular-ui-kit/carousel';
import { MdbCheckboxModule } from 'mdb-angular-ui-kit/checkbox';
import { MdbCollapseModule } from 'mdb-angular-ui-kit/collapse';
import { MdbDropdownModule } from 'mdb-angular-ui-kit/dropdown';
import { MdbFormsModule } from 'mdb-angular-ui-kit/forms';
import { MdbModalModule } from 'mdb-angular-ui-kit/modal';
import { MdbPopoverModule } from 'mdb-angular-ui-kit/popover';
import { MdbRadioModule } from 'mdb-angular-ui-kit/radio';
import { MdbRangeModule } from 'mdb-angular-ui-kit/range';
import { MdbRippleModule } from 'mdb-angular-ui-kit/ripple';
import { MdbScrollspyModule } from 'mdb-angular-ui-kit/scrollspy';
import { MdbTabsModule } from 'mdb-angular-ui-kit/tabs';
import { MdbTooltipModule } from 'mdb-angular-ui-kit/tooltip';
import { MdbValidationModule } from 'mdb-angular-ui-kit/validation';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LandingsiteComponent } from './components/landingsite/landingsite.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {HttpClientModule} from "@angular/common/http";
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { UserDashboardComponent } from './components/user-dashboard/user-dashboard.component';
import { RestaurantDashboardComponent } from './components/restaurant-dashboard/restaurant-dashboard.component';
import { DishCardComponent } from './components/dish-card/dish-card.component';
import { ViewRestaurantComponent } from './components/view-restaurant/view-restaurant.component';
import { RestaurantRegisterComponent } from './components/restaurant-register/restaurant-register.component';
import { DishAddComponent } from './components/dish-add/dish-add.component';
import { DishViewComponent } from './components/dish-view/dish-view.component';
import { RestaurantViewComponent } from './components/restaurant-view/restaurant-view.component';
import { RestaurantCardComponent } from './components/restaurant-card/restaurant-card.component';
import { UserNavbarComponent } from './components/user-navbar/user-navbar.component';
import { UserViewRestaurantComponent } from './components/user-view-restaurant/user-view-restaurant.component';
import { RegisterQuestionComponent } from './components/register-question/register-question.component';
import { SearchFilterPipe } from './pipes/search-filter.pipe';
import { CartComponent } from './components/cart/cart.component';
import { CartModalComponent } from './components/cart-modal/cart-modal.component';
import { ViewRestaurantNavComponent } from './components/view-restaurant-nav/view-restaurant-nav.component';
import { EditRestaurantComponent } from './components/edit-restaurant/edit-restaurant.component';
import { EditRestaurantDialogComponent } from './components/edit-restaurant-dialog/edit-restaurant-dialog.component';
import { RestaurantCardRvComponent } from './components/restaurant-card-rv/restaurant-card-rv.component';
import { RestaurantViewRvComponent } from './components/restaurant-view-rv/restaurant-view-rv.component';
import { UserDishCardComponent } from './components/user-dish-card/user-dish-card.component';
import { CartCardComponent } from './components/cart-card/cart-card.component';
import { InfoModalRestaurantComponent } from './components/info-modal-restaurant/info-modal-restaurant.component';
import { ViewAfterOrderingComponent } from './components/view-after-ordering/view-after-ordering.component';
import { CartCardLastComponent } from './components/cart-card-last/cart-card-last.component';
import { RestaurantOrderViewComponent } from './components/restaurant-order-view/restaurant-order-view.component';
import { EditDishCardComponent } from './components/edit-dish-card/edit-dish-card.component';
import { EditDishCardDialogComponent } from './components/edit-dish-card-dialog/edit-dish-card-dialog.component';
import { RestaurantTransactionsComponent } from './components/restaurant-transactions/restaurant-transactions.component';
import {MatDialogModule} from "@angular/material/dialog";
import { AdminViewComponent } from './components/admin-dashboard/admin-view/admin-view.component';
import { DataCardComponent } from './components/admin-dashboard/data-card/data-card.component';
import { DistComponent } from './components/admin-dashboard/dist/dist.component';
import { AdminNavbarComponent } from './components/admin-dashboard/admin-view/admin-navbar/admin-navbar.component';
import { AdminTableComponent } from './components/admin-dashboard/admin-view/admin-table/admin-table.component';
import {DataTablesModule} from "angular-datatables";
import { EditOrderComponent } from './components/admin-dashboard/admin-view/admin-table/edit-order/edit-order.component';

@NgModule({
  declarations: [
    AppComponent,
    LandingsiteComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    RegisterComponent,
    AdminDashboardComponent,
    UserDashboardComponent,
    RestaurantDashboardComponent,
    DishCardComponent,
    ViewRestaurantComponent,
    RestaurantRegisterComponent,
    DishAddComponent,
    DishViewComponent,
    RestaurantCardComponent,
    UserNavbarComponent,
    UserViewRestaurantComponent,
    RegisterQuestionComponent,
    SearchFilterPipe,
    RestaurantViewComponent,
    CartComponent,
    CartModalComponent,
    ViewRestaurantNavComponent,
    EditRestaurantComponent,
    EditRestaurantDialogComponent,
    RestaurantCardRvComponent,
    RestaurantViewRvComponent,
    UserDishCardComponent,
    CartCardComponent,
    InfoModalRestaurantComponent,
    ViewAfterOrderingComponent,
    CartCardLastComponent,
    RestaurantOrderViewComponent,
    EditDishCardComponent,
    EditDishCardDialogComponent,
    RestaurantTransactionsComponent,
    AdminViewComponent,
    DataCardComponent,
    DistComponent,
    AdminNavbarComponent,
    AdminTableComponent,
    EditOrderComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MdbAccordionModule,
    MdbCarouselModule,
    MdbCheckboxModule,
    MdbCollapseModule,
    MdbDropdownModule,
    MdbFormsModule,
    MdbModalModule,
    MdbPopoverModule,
    MdbRadioModule,
    MdbRangeModule,
    MdbRippleModule,
    MdbScrollspyModule,
    MdbTabsModule,
    MdbTooltipModule,
    MdbValidationModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    MatDialogModule,
    DataTablesModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
