import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import {RouteService} from "./services/route.service";

@Injectable({
  providedIn: 'root'
})
export class FoodieGuard implements CanActivate {

  constructor(private routserv : RouteService) {
  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    const tok = sessionStorage.getItem("mytoken");

    if(tok == null){
      console.log("Something went wrong in guard")
      this.routserv.goToLogin()
      return false;
    }
    return true;
  }
}
