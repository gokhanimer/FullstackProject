import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAfterOrderingComponent } from './view-after-ordering.component';

describe('ViewAfterOrderingComponent', () => {
  let component: ViewAfterOrderingComponent;
  let fixture: ComponentFixture<ViewAfterOrderingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAfterOrderingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAfterOrderingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
