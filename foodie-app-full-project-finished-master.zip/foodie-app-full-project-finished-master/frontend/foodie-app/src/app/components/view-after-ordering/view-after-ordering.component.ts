import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-after-ordering',
  templateUrl: './view-after-ordering.component.html',
  styleUrls: ['./view-after-ordering.component.scss']
})
export class ViewAfterOrderingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
