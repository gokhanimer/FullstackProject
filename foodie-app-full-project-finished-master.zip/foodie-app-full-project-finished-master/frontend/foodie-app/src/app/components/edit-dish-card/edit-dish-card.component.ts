import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {ActivatedRoute} from "@angular/router";
import {RouteService} from "../../services/route.service";

@Component({
  selector: 'app-edit-dish-card',
  templateUrl: './edit-dish-card.component.html',
  styleUrls: ['./edit-dish-card.component.scss']
})
export class EditDishCardComponent implements OnInit {

  constructor(private route: ActivatedRoute, private dialog: MatDialog, private router: RouteService) { }

  ngOnInit(): void {
  }

}
