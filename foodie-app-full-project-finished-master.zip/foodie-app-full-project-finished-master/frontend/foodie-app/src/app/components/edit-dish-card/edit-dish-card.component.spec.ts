import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDishCardComponent } from './edit-dish-card.component';

describe('EditDishCardComponent', () => {
  let component: EditDishCardComponent;
  let fixture: ComponentFixture<EditDishCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditDishCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDishCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
