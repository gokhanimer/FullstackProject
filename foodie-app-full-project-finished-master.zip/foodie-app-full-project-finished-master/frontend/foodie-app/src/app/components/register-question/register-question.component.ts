import { Component, OnInit } from '@angular/core';
import {Restaurant} from "../../model/restaurant";
import {RouteService} from "../../services/route.service";
import {RestaurantService} from "../../services/restaurant.service";

@Component({
  selector: 'app-register-question',
  templateUrl: './register-question.component.html',
  styleUrls: ['./register-question.component.scss']
})
export class RegisterQuestionComponent implements OnInit {
  allRest: Array<Restaurant> = [];

  constructor(private restaurantService : RestaurantService, private route: RouteService) {
    this.allRest = [];
  }

  ngOnInit(): void {
    this.restaurantService.getRestaurants().subscribe(allrest => {
        this.allRest = allrest
      },
      err => {
        console.warn(err);
      });
  }

  checkMyRestaurant(number : string, id : string){
    console.log("Now we test!");
    this.allRest.forEach(rest => {
      if((rest.restaurantId == Number(id)) && (rest.phonenumber == Number(number))){
      console.log(rest.restaurantId + "This works!");
      this.route.goToRestaurantDashboard();
    }else{
     console.log("Something wrong")
    }
    });
  }

  goToRegister(){
    this.route.goToRestaurantRegister();
  }
}
