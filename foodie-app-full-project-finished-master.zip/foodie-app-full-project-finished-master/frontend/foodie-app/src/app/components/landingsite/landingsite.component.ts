import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landingsite',
  templateUrl: './landingsite.component.html',
  styleUrls: ['./landingsite.component.scss']
})
export class LandingsiteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
