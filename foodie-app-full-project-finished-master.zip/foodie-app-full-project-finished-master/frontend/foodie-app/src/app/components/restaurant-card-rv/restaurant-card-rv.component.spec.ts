import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantCardRvComponent } from './restaurant-card-rv.component';

describe('RestaurantCardRvComponent', () => {
  let component: RestaurantCardRvComponent;
  let fixture: ComponentFixture<RestaurantCardRvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RestaurantCardRvComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantCardRvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
