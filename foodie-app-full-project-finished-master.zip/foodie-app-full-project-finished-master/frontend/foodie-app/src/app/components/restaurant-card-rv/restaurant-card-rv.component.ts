import { Component, Input, OnInit, Output, EventEmitter} from '@angular/core';
import { Restaurant } from 'src/app/model/restaurant';
import { RestaurantService } from 'src/app/services/restaurant.service';
import { RouteService } from 'src/app/services/route.service';

@Component({
  selector: 'app-restaurant-card-rv',
  templateUrl: './restaurant-card-rv.component.html',
  styleUrls: ['./restaurant-card-rv.component.scss']
})
export class RestaurantCardRvComponent implements OnInit {
  rating:number;

  @Input()
  public restaurant : Restaurant;
  @Output()
  public deleteEvent = new EventEmitter();

  constructor(private restaurantService: RestaurantService, private routerService : RouteService) {
  }
  ngOnInit(): void {
    this.restaurantService.getRating(this.restaurant.restaurantId).subscribe(fresRating =>{
      this.rating = fresRating;
    })
  }

  editRestaurant() {
    this.routerService.navigateToEdit(this.restaurant.restaurantId)
  }

  dishes() {
    let id = this.restaurant.restaurantId;
    sessionStorage.setItem('id',id.toString())
    console.log(id)
    this.routerService.goToDishesForRestaurant()
  }

  deleteRestaurant() {
    this.deleteEvent.emit(this.restaurant.restaurantId);
    window.location.reload();
  }

}
