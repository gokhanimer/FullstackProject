import {Component, Input, OnInit} from '@angular/core';
import {DishService} from "../../services/dish.service";
import {Dish} from "../../model/dish";

@Component({
  selector: 'app-cart-card-last',
  templateUrl: './cart-card-last.component.html',
  styleUrls: ['./cart-card-last.component.scss']
})
export class CartCardLastComponent implements OnInit {
  cardImage: string ="";
  allDishesInCart: Array<Dish> = [];
  numbersOfDish: number = 0;

  @Input()
  public dish : Dish;

  constructor(private dishService: DishService) { }

  ngOnInit(): void {
    this.allDishesInCart = this.dishService.getAllDishFromArrayToCheckout();
    this.countNumberOfDish();
    for (let ing of this.dish.ingredients) {
      if(ing.toLowerCase() == "noodle"){
        this.cardImage = "https://images.pexels.com/photos/2664216/pexels-photo-2664216.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "chicken"){
        this.cardImage = "https://images.pexels.com/photos/33406/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "meat"){
        this.cardImage = "https://images.pexels.com/photos/299347/pexels-photo-299347.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "rice"){
        this.cardImage = "https://images.pexels.com/photos/33406/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "cauliflower"){
        this.cardImage = "https://images.pexels.com/photos/5695893/pexels-photo-5695893.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "water"){
        this.cardImage = "https://images.pexels.com/photos/1618888/pexels-photo-1618888.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "shrimp"){
        this.cardImage = "https://images.pexels.com/photos/566345/pexels-photo-566345.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }
      else{
        this.cardImage = "https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }
    }
  }

  countNumberOfDish(){
    this.numbersOfDish = 0;
    this.allDishesInCart.forEach(arrayDish => {
      if(arrayDish.dishName == this.dish.dishName){
        this.numbersOfDish += 1;
      }
    })
  }

}
