import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CartCardLastComponent } from './cart-card-last.component';

describe('CartCardLastComponent', () => {
  let component: CartCardLastComponent;
  let fixture: ComponentFixture<CartCardLastComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CartCardLastComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CartCardLastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
