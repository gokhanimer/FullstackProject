import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Dish } from 'src/app/model/dish';
import { DishService } from 'src/app/services/dish.service';
import {EditDishCardComponent} from "../edit-dish-card/edit-dish-card.component";

@Component({
  selector: 'app-edit-dish-card-dialog',
  templateUrl: './edit-dish-card-dialog.component.html',
  styleUrls: ['./edit-dish-card-dialog.component.scss']
})
export class EditDishCardDialogComponent implements OnInit {

  public dish: Dish;
  public id: number;
  ingredients : String;

  constructor(public dialogRef : MatDialogRef<EditDishCardComponent>, public dialog: MatDialog,
              @Inject(MAT_DIALOG_DATA) public data : any, private service : DishService) { }

  ngOnInit(): void {
    this.dish = this.data.dish;
    this.id = this.data.id;
    this.ingredients = this.dish.ingredients.toString();
  }

  UpdateDish(){
    this.dish.ingredients = this.ingredients.split(", ")
    console.log(this.id,this.dish);
    this.service.updateDish(this.id,this.dish).subscribe(resp=>{
      this.dialogRef.close();
    })

  }


}
