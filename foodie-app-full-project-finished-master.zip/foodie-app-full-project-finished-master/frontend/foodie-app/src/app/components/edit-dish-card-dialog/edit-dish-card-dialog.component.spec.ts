import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDishCardDialogComponent } from './edit-dish-card-dialog.component';

describe('EditDishCardDialogComponent', () => {
  let component: EditDishCardDialogComponent;
  let fixture: ComponentFixture<EditDishCardDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditDishCardDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDishCardDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
