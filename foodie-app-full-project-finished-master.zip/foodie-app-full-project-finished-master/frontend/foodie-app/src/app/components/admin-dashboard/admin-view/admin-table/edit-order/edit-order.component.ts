import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TransactionService } from 'src/app/services/transaction.service';

@Component({
  selector: 'app-edit-order',
  templateUrl: './edit-order.component.html',
  styleUrls: ['./edit-order.component.scss']
})
export class EditOrderComponent implements OnInit {

  public orderEditForm = new FormGroup({
    dishName: new FormControl('', Validators.nullValidator),
    totalPrice: new FormControl('', [Validators.minLength(4)]),
    status: new FormControl('', Validators.nullValidator),
    paymentMethod: new FormControl('', Validators.nullValidator)
  });

  public updateTransaction(): void {
    console.log(
      this.orderEditForm.controls['dishName'].value,
      this.orderEditForm.controls['totalPrice'].value,
      this.orderEditForm.controls['status'].value,
      this.orderEditForm.controls['paymentMethod'].value,
    );
  }



  transId: string;
  loading = false;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private transactionService: TransactionService,
  ) {}

  ngOnInit() {
    this.transId = this.route.snapshot.params['transId'];

  }
}

/*orderEditForm = new FormBuilder.group({
  dishName: ['', Validators.nullValidator],
  totalPrice: ['', [Validators.minLength(4)], Validators.nullValidator],
  status: ['', Validators.nullValidator],
  paymentMethod: ['', Validators.nullValidator],
});*/

/*get form() {
  return this.form.controls;
}

function updateTransaction() {
  this.transactionService.update(this.transId, this.form.value)
      .pipe(first())
      .subscribe({
        next: () => {
          this.router.navigate(['/admin-dashboard']);
        },
        errorEvent: (error : any) => {
          return "Something went wrong!";
        }
      });
    }*/


