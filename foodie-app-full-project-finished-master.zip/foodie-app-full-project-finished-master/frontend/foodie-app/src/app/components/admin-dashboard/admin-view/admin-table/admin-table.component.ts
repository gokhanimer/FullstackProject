import { Component, OnInit, OnDestroy} from '@angular/core';
import { TransactionService } from 'src/app/services/transaction.service';
import { Subject } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-table',
  templateUrl: './admin-table.component.html',
  styleUrls: ['./admin-table.component.scss']
})
export class AdminTableComponent implements OnInit, OnDestroy {

  Transactions:any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();
  filterTerm!: string;

  constructor(private transactionService: TransactionService, private router : Router) { }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

  ngOnInit(): void {
    this.transactionService.getTransactions().subscribe(transaction => {
      console.log(transaction)
      this.Transactions = transaction;
    });
  }

  transactions(): void {
    this.transactionService
      .getTransactions().subscribe((response: any) => {
      this.transactions = response;
      this.dtTrigger.next(response);
    });
  }

  delete(id:any, i:any) {
    console.log(id);
    if(window.confirm('You are about to delete a transaction')) {
      this.transactionService.deleteTransaction(id).subscribe((_transaction : string) => {
        this.Transactions.splice(i, 1);
      })
    }
  }

  btnClick = function () {
    this.router.navigateByUrl('./edit-order');
  };
}
