import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RestaurantService } from 'src/app/services/restaurant.service';
import { Subject } from 'rxjs';


@Component({
  selector: 'app-data-card',
  templateUrl: './data-card.component.html',
  styleUrls: ['./data-card.component.scss']
})
export class DataCardComponent implements OnInit {

  Restaurants:any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>()
  filterTerm!: string;


  constructor(private restaurantService: RestaurantService, private router: Router, private route: ActivatedRoute) {}
  ngOnInit(): void {

    this.restaurantService.getRestaurants().subscribe(restaurant => {
      console.log(restaurant)
      this.Restaurants = restaurant;
    });
  }

  restaurants(): void {
    this.restaurantService
      .getRestaurants().subscribe((response: any) => {
      this.restaurants = response;
      this.dtTrigger.next(response);
    });
  }

  approveRestaurant(restaurantId: number){
    console.log(restaurantId);
    this.restaurantService.updateRestaurantApprovalStatus(restaurantId, true).subscribe(res => console.log(restaurantId +" is now true"));
    location.reload();
  }

  disapproveRestaurant(restaurantId: number){
    this.restaurantService.updateRestaurantApprovalStatus(restaurantId, false).subscribe(res => console.log(restaurantId +" is now false"));
    location.reload();
  }
}
