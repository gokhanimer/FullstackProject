import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import { Dish } from 'src/app/model/dish';
import {RouteService} from "../../services/route.service";
import {ActivatedRoute} from "@angular/router";
import {MatDialog} from "@angular/material/dialog";
import {EditDishCardDialogComponent} from "../edit-dish-card-dialog/edit-dish-card-dialog.component";

@Component({
  selector: 'app-dish-card',
  templateUrl: './dish-card.component.html',
  styleUrls: ['./dish-card.component.scss']
})
export class DishCardComponent implements OnInit {
  @Input()
  public obj : {id:number,dish:Dish}


  @Output()
  public deleteEvent = new EventEmitter<{id:number,dishName:string}>();
  public updateEvent = new EventEmitter<{id:number,dish:Dish}>();

  constructor(private routerService : RouteService,private route: ActivatedRoute,private dialog: MatDialog) { }

  ngOnInit(): void {
  }

  deleteDish() {
    console.log("From child " + this.obj.id);
    this.deleteEvent.emit({id:this.obj.id,dishName:this.obj.dish.dishName});
  }

  updateDish() {
    console.log("From child " + this.obj.id);
    this.updateEvent.emit({id:this.obj.id, dish:this.obj.dish});
  }
  editDish() {
    this.route.params.subscribe(params => {
      this.dialog.open(EditDishCardDialogComponent, {
        data: {'id': this.obj.id,
          'dish': this.obj.dish}
      })
    })
  }

}
