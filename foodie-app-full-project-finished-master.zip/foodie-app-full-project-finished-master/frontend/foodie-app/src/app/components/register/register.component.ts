import { Component, OnInit } from '@angular/core';
import {Userprofile} from "../../model/userprofile";
import {Router} from "@angular/router";
import {UserService} from "../../services/user.service";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {


  reguserprofile : Userprofile = new Userprofile();

  constructor(private route : Router, private userService: UserService ) {}
  ngOnInit(): void {}

  registerUser(){
    this.userService.registerUser(this.reguserprofile);
    this.route.navigate(['login']).then(() => {
      window.location.reload();})

  }

}
