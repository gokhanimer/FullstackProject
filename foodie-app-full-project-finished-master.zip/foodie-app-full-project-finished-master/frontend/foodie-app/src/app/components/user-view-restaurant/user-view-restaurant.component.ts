import {Component, Input, OnInit} from '@angular/core';
import {Restaurant} from "../../model/restaurant";
import {RestaurantViewComponent} from "../restaurant-view/restaurant-view.component";

@Component({
  selector: 'app-user-view-restaurant',
  templateUrl: './user-view-restaurant.component.html',
  styleUrls: ['./user-view-restaurant.component.scss']
})
export class UserViewRestaurantComponent implements OnInit {

  allRest: Array<Restaurant> = [];

  @Input()
  public restaurant : Restaurant;

  constructor(private restView: RestaurantViewComponent) {
    this.allRest = [];
  }

  ngOnInit(): void {
    this.allRest = this.restView.allRest;
  }


}
