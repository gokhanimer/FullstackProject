import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {Dish} from "../../model/dish";
import {DishService} from "../../services/dish.service";

@Component({
  selector: 'app-user-dish-card',
  templateUrl: './user-dish-card.component.html',
  styleUrls: ['./user-dish-card.component.scss']
})
export class UserDishCardComponent implements OnInit {

  message: string;
  cardImage: string;

  @Input()
  public dish : Dish;

  constructor(private dishService: DishService) { }

  ngOnInit(): void {
    for (let ing of this.dish.ingredients) {
      if(ing.toLowerCase() == "noodle"){
        this.cardImage = "https://images.pexels.com/photos/2664216/pexels-photo-2664216.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "chicken"){
        this.cardImage = "https://images.pexels.com/photos/33406/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "meat"){
        this.cardImage = "https://images.pexels.com/photos/299347/pexels-photo-299347.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "rice"){
        this.cardImage = "https://images.pexels.com/photos/33406/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "cauliflower"){
        this.cardImage = "https://images.pexels.com/photos/5695893/pexels-photo-5695893.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "water"){
        this.cardImage = "https://images.pexels.com/photos/1618888/pexels-photo-1618888.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "shrimp"){
        this.cardImage = "https://images.pexels.com/photos/566345/pexels-photo-566345.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }
      else{
        this.cardImage = "https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }
    }
  }

  addToCart(dish: Dish){
    this.dishService.addDishToCart(dish);
    this.sendMessage(dish.dishName + " added")
    this.clearMessage();
  }

  sendMessage(input: string){
    this.message = "";
    this.message = input;
  }

  clearMessage(){
    setTimeout(() => {
      this.message = null;
    }, 1000);
  }

}
