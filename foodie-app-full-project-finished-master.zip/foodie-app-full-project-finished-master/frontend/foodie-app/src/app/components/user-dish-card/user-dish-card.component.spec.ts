import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserDishCardComponent } from './user-dish-card.component';

describe('UserDishCardComponent', () => {
  let component: UserDishCardComponent;
  let fixture: ComponentFixture<UserDishCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserDishCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDishCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
