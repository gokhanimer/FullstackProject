import {Component, Input, OnInit} from '@angular/core';
import {RestaurantService} from "../../services/restaurant.service";
import {Restaurant} from "../../model/restaurant";
import {RestaurantCardComponent} from "../restaurant-card/restaurant-card.component";

@Component({
  selector: 'app-restaurant-view',
  templateUrl: './restaurant-view.component.html',
  styleUrls: ['./restaurant-view.component.scss']
})
export class RestaurantViewComponent implements OnInit {

  allRest: Array<Restaurant> = [];
  allRestTrue: Array<Restaurant> = [];
  public searchtext: string = "";

  constructor(private restService : RestaurantService) {
    this.allRest = [];
    this.allRestTrue = [];
  }

  ngOnInit(): void {
    this.restService.getRestaurants().subscribe(allrest => {
        this.allRest = allrest

      },
      err => {
        console.warn(err);
      });

    this.restService.getRestaurantsWhichIsTrue().subscribe(allRestByTrue => {
        this.allRestTrue = allRestByTrue;
      },
      err => {
        console.warn(err);
      });

  }

}
