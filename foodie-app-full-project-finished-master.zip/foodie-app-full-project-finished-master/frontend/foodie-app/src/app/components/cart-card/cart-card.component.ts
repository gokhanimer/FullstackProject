import {Component, Input, OnInit} from '@angular/core';
import {Dish} from "../../model/dish";
import {DishService} from "../../services/dish.service";
import {CartModalComponent} from "../cart-modal/cart-modal.component";

@Component({
  selector: 'app-cart-card',
  templateUrl: './cart-card.component.html',
  styleUrls: ['./cart-card.component.scss']
})
export class CartCardComponent implements OnInit {

  message: string;
  cardImage: string ="";
  allDishesInCart: Array<Dish> = [];
  numbersOfDish: number = 0;


  @Input()
  public dish : Dish;

  constructor(private dishService: DishService, private cartModal: CartModalComponent) { }

  ngOnInit(): void {
    this.allDishesInCart = this.dishService.getAllDishFromArrayToCheckout();
    this.countNumberOfDish();

    for (let ing of this.dish.ingredients) {
      if(ing.toLowerCase() == "noodle"){
        this.cardImage = "https://images.pexels.com/photos/2664216/pexels-photo-2664216.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "chicken"){
        this.cardImage = "https://images.pexels.com/photos/33406/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "meat"){
        this.cardImage = "https://images.pexels.com/photos/299347/pexels-photo-299347.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "rice"){
        this.cardImage = "https://images.pexels.com/photos/33406/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "cauliflower"){
        this.cardImage = "https://images.pexels.com/photos/5695893/pexels-photo-5695893.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "water"){
        this.cardImage = "https://images.pexels.com/photos/1618888/pexels-photo-1618888.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }else if(ing.toLowerCase() == "shrimp"){
        this.cardImage = "https://images.pexels.com/photos/566345/pexels-photo-566345.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }
      else{
        this.cardImage = "https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1";
        break;
      }
    }
  }

  countNumberOfDish(){
    this.numbersOfDish = 0;
    this.allDishesInCart.forEach(arrayDish => {
      if(arrayDish.dishName == this.dish.dishName){
        this.numbersOfDish += 1;
      }
    })
  }

  addDish(dish: Dish){
    this.dishService.addDishToCart(dish);
    this.countNumberOfDish();
  }

  removeDish(dish: Dish){
    if(this.numbersOfDish > 0){
      this.dishService.removeDishFromCart(dish);
      this.countNumberOfDish();
    }else{
      this.deleteAllSpecificDishFromArray(dish);
      this.closeModal();
    }
  }

  deleteAllSpecificDishFromArray(dish: Dish){
    for (var i = this.allDishesInCart.length - 1; i >= 0; --i) {
      if (this.allDishesInCart[i].dishName == dish.dishName) {
        this.allDishesInCart.splice(i,1);
        }

      }
      this.sendMessage("Dish deleted");
      this.clearMessage();
      this.closeModal();
  }

  clearMessage(){
    setTimeout(() => {
      this.message = null;
    }, 1000);
  }

  sendMessage(input: string){
    this.message = "";
    this.message = input;
  }

  closeModal(){
    this.cartModal.closeModal();
  }

}
