import { Component, OnInit } from '@angular/core';
import { Restaurant } from 'src/app/model/restaurant';
import { Transaction } from 'src/app/model/transaction';
import { RestaurantService } from 'src/app/services/restaurant.service';
import { RouteService } from 'src/app/services/route.service';
import { TransactionService } from 'src/app/services/transaction.service';

@Component({
  selector: 'app-restaurant-transactions',
  templateUrl: './restaurant-transactions.component.html',
  styleUrls: ['./restaurant-transactions.component.scss']
})
export class RestaurantTransactionsComponent implements OnInit {

  username: string = "";
  allTrans : Array<Transaction> = [];
  allTransByUsername : Array<Transaction> = [];

  allRest: Array<Restaurant> = [];
  allRestByUname: Array<Restaurant> = [];

  constructor(private transService : TransactionService, private routeService: RouteService, private restService: RestaurantService) {

  }

  ngOnInit(): void {
    this.username = sessionStorage.getItem("username");
    this.restService.getRestaurants().subscribe(allrest => {
        this.allRest = allrest;
        this.allRest.forEach(rest => {
          if(rest.username == this.username){
            this.allRestByUname.push(rest);
          }
        })
      },
      err => {
        console.warn(err);
      });
    this.transService.getAllTransactions().forEach(trans => {
      this.allTrans = trans;
    })

  }

  showAllRest(){
    this.allTrans.forEach(trans => {
      this.allRestByUname.forEach(rest => {
        if(trans.restaurantId == rest.restaurantId){
          this.allTransByUsername.push(trans);
        }
      })
    })
  }

  goBack(){
    this.routeService.goBack();
  }
}

