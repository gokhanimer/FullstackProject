import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantTransactionsComponent } from './restaurant-transactions.component';

describe('RestaurantTransactionsComponent', () => {
  let component: RestaurantTransactionsComponent;
  let fixture: ComponentFixture<RestaurantTransactionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RestaurantTransactionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantTransactionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
