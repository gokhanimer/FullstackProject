import { Component, Inject, OnInit } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA, MatDialog} from '@angular/material/dialog';
import { Restaurant } from 'src/app/model/restaurant';
import { RestaurantService } from 'src/app/services/restaurant.service';

@Component({
  selector: 'app-edit-restaurant-dialog',
  templateUrl: './edit-restaurant-dialog.component.html',
  styleUrls: ['./edit-restaurant-dialog.component.scss']
})
export class EditRestaurantDialogComponent implements OnInit {

  public restaurant : Restaurant;

  restaurantId: string;

  constructor(public dialogRef : MatDialogRef<EditRestaurantDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data : any, private service : RestaurantService, public dialog: MatDialog) { }

  ngOnInit() {
    console.log(this.data.id);
    this.restaurant = this.service.getRestaurantById(this.data.restaurantId);
    console.log(this.restaurant);
  }

  saveRestaurant(form) {
    this.service.saveRestaurant(this.restaurant).subscribe(restaurant =>{
      this.dialogRef.close();
    })
  }
}
