import {Component, Input, OnInit, ViewChild, AfterViewInit, Output, EventEmitter} from '@angular/core';
import { Observable, observable } from 'rxjs';
import {Restaurant} from "../../model/restaurant";
import {RestaurantService} from "../../services/restaurant.service";
import {RouteService} from "../../services/route.service";

@Component({
  selector: 'app-restaurant-card',
  templateUrl: './restaurant-card.component.html',
  styleUrls: ['./restaurant-card.component.scss']
})
export class RestaurantCardComponent implements OnInit {
  rating: number;
  newRating : number;

  @Input()
  public restaurant : Restaurant;

  message = "this a sent message";

  constructor(private restaurantService: RestaurantService, private route: RouteService) {
  }
  ngOnInit(): void {
    this.restaurantService.getRating(this.restaurant.restaurantId).subscribe(fresRating =>{
      this.rating = fresRating;
    })
  }

  rateRestaurant(){
    let userName = sessionStorage.getItem("username");
    console.log("Trying to rate restaurant"+this.newRating)
    const newRating = this.restaurantService.updateRestaurantRating(this.restaurant.restaurantId,this.newRating, userName);
    newRating.subscribe(float =>{
      this.rating = float;
      console.log("new rating "+this.rating)
    })
  }

  goToRestaurant(restaurantId: number){
    console.log("Button is clicked with id " + restaurantId);
    this.route.goToRestaurantView();
  }

  changeId(restaurantId: number) {
    this.restaurantService.changeId(restaurantId);
    this.route.goToRestaurantView();
  }
}
