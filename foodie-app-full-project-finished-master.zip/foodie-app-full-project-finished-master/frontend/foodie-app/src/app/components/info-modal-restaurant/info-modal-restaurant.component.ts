import { Component, OnInit } from '@angular/core';
import {Dish} from "../../model/dish";
import {MdbModalRef} from "mdb-angular-ui-kit/modal";
import {RouteService} from "../../services/route.service";
import {DishService} from "../../services/dish.service";

@Component({
  selector: 'app-info-modal-restaurant',
  templateUrl: './info-modal-restaurant.component.html',
  styleUrls: ['./info-modal-restaurant.component.scss']
})
export class InfoModalRestaurantComponent implements OnInit {

  title: string | null = null;
  address: string | null = null;
  number: number | null = null;
  category: string | null = null;


  constructor(public modalRef: MdbModalRef<InfoModalRestaurantComponent>) { }

  ngOnInit(): void {
  }

}
