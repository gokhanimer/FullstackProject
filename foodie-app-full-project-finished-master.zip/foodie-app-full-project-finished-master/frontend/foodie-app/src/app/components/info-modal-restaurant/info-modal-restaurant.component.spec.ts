import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoModalRestaurantComponent } from './info-modal-restaurant.component';

describe('InfoModalRestaurantComponent', () => {
  let component: InfoModalRestaurantComponent;
  let fixture: ComponentFixture<InfoModalRestaurantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InfoModalRestaurantComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoModalRestaurantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
