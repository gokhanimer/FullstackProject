import {Component, Input, OnInit} from '@angular/core';
import {DishService} from "../../services/dish.service";
import {Dish} from "../../model/dish";
import { Restaurant } from 'src/app/model/restaurant';
import { Transaction } from 'src/app/model/transaction';
import {RouteService} from "../../services/route.service";
import {TransactionService} from "../../services/transaction.service";

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {

  username: string = "";
  restaurant: Restaurant;

  transaction : Transaction = new Transaction();
  transactionId: string;


  allDishNames: Array<string> = [];
  allDishes: Array<Dish>;
  allSingelDishes: Array<Dish>;
  totalPrice: number;
  beforeTaxPrice: number;

  allTransactionByUsername: Array<Transaction> = [];
  allTransactions: Array<Transaction>;


  constructor(private dishService: DishService, private transactionService: TransactionService, private routeService: RouteService) {
    this.beforeTaxPrice = 0;
    this.totalPrice = 0;
  }

  ngOnInit(): void {
    this.allSingelDishes = this.dishService.getAllSingleDishesInCart();
    this.allDishes = this.dishService.getAllDishFromArrayToCheckout();
    this.allDishes.forEach(dish =>{
      this.beforeTaxPrice += dish.price;

    });
    this.totalPrice = Math.round(this.beforeTaxPrice * 1.12);
    this.username = sessionStorage.getItem("username");
    this.restaurant = JSON.parse(sessionStorage.getItem("restaurant"));
  }

  goToRestaurantView() {
    this.routeService.goToRestaurantView();
  }

  submitTransaction(payType: string){
    this.createUniqueId();
    this.allDishes.forEach(dish => {
      this.allDishNames.push(dish.dishName);
    });

    let date = new Date().toISOString().substring(0,10);
    console.log(date);
    this.transaction.transId = this.transactionId;
    this.transaction.totalPrice = this.totalPrice;
    this.transaction.restaurantId = this.restaurant.restaurantId;
    this.transaction.date = date.toString();
    this.transaction.status = "Being cooked";
    this.transaction.dishName = this.allDishNames;
    this.transaction.paymentMethod = payType;
    this.transaction.username = this.username;

    if(this.totalPrice > 0){
      this.transactionService.addTransaction(this.transaction);
      this.clearCart2();
      this.routeService.goToOrderView();
    }else{
      alert("Cart is empty!");
    }
  }

  clearCart(){
    this.dishService.clearAllDishFromArray();
    location.reload();
  }

  clearCart2(){
    this.dishService.clearAllDishFromArray();
  }

  createUniqueId(){
    this.transactionId = '_' + Math.random().toString(36).substr(2, 9);
  }

}
