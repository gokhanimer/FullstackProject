import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { RouteService } from 'src/app/services/route.service';
import {Dish} from "../../model/dish";
import {DishService} from "../../services/dish.service";

@Component({
  selector: 'app-dish-view',
  templateUrl: './dish-view.component.html',
  styleUrls: ['./dish-view.component.scss']
})
export class DishViewComponent implements OnInit {

  allMenuArray: Array<{id:number, dish:Dish}> = [];
  id : number;
  dish : Dish = new Dish();
  ingredients : String;



  constructor(private dishService : DishService, private route: ActivatedRoute, private routeService: RouteService) {
    this.allMenuArray = [];
  }

  ngOnInit(): void {

    this.id = parseInt(sessionStorage.getItem("id"), 10);
    console.log("id in dish-view is: "+this.id);
    this.dishService.getDishFromServerByRestaurantId(this.id).subscribe(menu => {
        let id = menu.restaurantId;
        menu.dishes.map(dish =>this.allMenuArray.push({id,dish}));
        console.log(this.allMenuArray);},
      err => {
        console.warn(err);
      });
  }

  removeDish({id,dishName}){
    console.log("Received in parent " + id);
    this.dishService.deleteDish(id, dishName).subscribe(
      resp => {
        const index = this.allMenuArray.findIndex(element=>element.id==id && element.dish.dishName==dishName)
        this.allMenuArray.splice(index,1)
      });
  }

  updateDish({id,dish}){
    console.log("Updating! Received in parent " + id);
    this.dishService.updateDish(id, dish).subscribe(
      resp => {
        const index = this.allMenuArray.findIndex(element=>element.id==id && element.dish.dishName==dish.dishName)
        this.allMenuArray[index] = {id,dish};
      });
  }


  addDish(){
    this.dish.ingredients = this.ingredients.split(", ");
    this.dishService.addDish(this.id,this.dish).subscribe(
      resp =>{
        var id = this.id;
        var dish = this.dish;
        this.allMenuArray.push({id,dish})
        this.dish = new Dish();
        this.ingredients = new String;
      });
  }
  goBack(){
    this.routeService.goBack();
  }

}
