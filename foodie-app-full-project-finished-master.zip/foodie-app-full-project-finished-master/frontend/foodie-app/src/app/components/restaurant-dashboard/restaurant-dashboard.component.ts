import { Component, OnInit } from '@angular/core';
import {RestaurantService} from "../../services/restaurant.service";
import {RouteService} from "../../services/route.service";
import {Userprofile} from "../../model/userprofile";

@Component({
  selector: 'app-restaurant-dashboard',
  templateUrl: './restaurant-dashboard.component.html',
  styleUrls: ['./restaurant-dashboard.component.scss']
})
export class RestaurantDashboardComponent implements OnInit {
  public user : Userprofile;

  constructor(private restService : RestaurantService, private myroute: RouteService) { }
  restaurant = this.restService.allRestaurants;

  displayName = '';

  ngOnInit(): void {
    this.displayName = localStorage.getItem('Username');
  }

  addRestaurant(){
    this.myroute.goToRestaurantRegister();
  }

  logout(){
    sessionStorage.clear();
    this.myroute.goToLogin();
  }
  viewOrders() {
    this.myroute.goToRestaurantTransactions();
  }

}
