import {Component, OnInit, ViewChild} from '@angular/core';
import {MdbModalRef} from "mdb-angular-ui-kit/modal";
import {RouteService} from "../../services/route.service";
import {Dish} from "../../model/dish";
import {DishService} from "../../services/dish.service";

@Component({
  selector: 'app-cart-modal',
  templateUrl: './cart-modal.component.html',
  styleUrls: ['./cart-modal.component.scss']
})
export class CartModalComponent implements OnInit {

  @ViewChild('myModalClose') modalClose;

  message: string;
  title: string | null = null;
  dishes: Array<Dish> | null = null;

  constructor(public modalRef: MdbModalRef<CartModalComponent>, private route: RouteService, private dishService: DishService) { }

  ngOnInit(): void {
    this.dishes = this.dishService.getAllSingleDishesInCart();
  }

  goToCart(){
    this.route.goToCart();
    this.modalRef.close()
  }

  clearCart(){
    this.dishService.clearAllDishFromArray();
    this.sendMessage("Shopping cart is now empty");
    this.clearMessage();
  }

  clearMessage(){
    setTimeout(() => {
      this.message = null;
      location.reload();
    }, 1000);
  }

  sendMessage(input: string){
    this.message = "";
    this.message = input;
  }

  closeModal(){
    this.modalClose.nativeElement.click();
  }


}
