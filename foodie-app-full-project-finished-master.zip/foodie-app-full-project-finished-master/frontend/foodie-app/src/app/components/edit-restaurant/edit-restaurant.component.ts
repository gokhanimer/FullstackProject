import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RouteService } from 'src/app/services/route.service';
import { EditRestaurantDialogComponent } from '../edit-restaurant-dialog/edit-restaurant-dialog.component';
import {MatDialog} from "@angular/material/dialog";

@Component({
  selector: 'app-edit-restaurant',
  templateUrl: './edit-restaurant.component.html',
  styleUrls: ['./edit-restaurant.component.scss']
})
export class EditRestaurantComponent implements OnInit {

  constructor(private route: ActivatedRoute, private dialog: MatDialog, private router: RouteService) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      const restaurantId = params['restaurantId'];
      this.dialog.open(EditRestaurantDialogComponent, {
        data: {'restaurantId': restaurantId}
      }).afterClosed().subscribe(
        result => {
          this.router.goBack();
        }
      )
    })
  }

}
