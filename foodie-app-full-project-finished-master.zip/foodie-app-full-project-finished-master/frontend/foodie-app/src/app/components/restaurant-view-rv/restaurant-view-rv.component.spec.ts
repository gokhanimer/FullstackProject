import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantViewRvComponent } from './restaurant-view-rv.component';

describe('RestaurantViewRvComponent', () => {
  let component: RestaurantViewRvComponent;
  let fixture: ComponentFixture<RestaurantViewRvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RestaurantViewRvComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantViewRvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
