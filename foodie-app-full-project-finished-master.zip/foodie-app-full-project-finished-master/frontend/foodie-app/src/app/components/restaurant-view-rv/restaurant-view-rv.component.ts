import { Component, OnInit } from '@angular/core';
import { Restaurant } from '../../model/restaurant';
import { RestaurantService } from '../../services/restaurant.service';
import {DishService} from "../../services/dish.service";

@Component({
  selector: 'app-restaurant-view-rv',
  templateUrl: './restaurant-view-rv.component.html',
  styleUrls: ['./restaurant-view-rv.component.scss']
})
export class RestaurantViewRvComponent implements OnInit {

  username: string = "";
  allRest: Array<Restaurant> = [];
  allRestByUname: Array<Restaurant> = [];

  constructor(private restService : RestaurantService, private dishService : DishService) {
    this.allRest = [];
  }

  ngOnInit(): void {
    this.username = sessionStorage.getItem("username");
    this.restService.getRestaurants().subscribe(allrest => {
        this.allRest = allrest;
        this.allRest.forEach(rest => {
          if(rest.username == this.username){
            this.allRestByUname.push(rest);
          }
        })
      },
      err => {
        console.warn(err);
      });
  }

  removeRestaurant(id) {
    console.log("Received in parent " + id);
    this.restService.deleteRestaurant(id).subscribe(
      resp => {
        const index = this.allRest.findIndex(rest => rest.restaurantId == id);
        this.allRest.splice(index, 1);
      }
    );
    this.dishService.deleteMenu(id);
  }


}
