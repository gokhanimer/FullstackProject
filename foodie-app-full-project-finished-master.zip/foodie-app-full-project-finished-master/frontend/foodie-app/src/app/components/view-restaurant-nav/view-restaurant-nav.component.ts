import { Component, OnInit } from '@angular/core';
import {RouteService} from "../../services/route.service";
import {DishService} from "../../services/dish.service";

@Component({
  selector: 'app-view-restaurant-nav',
  templateUrl: './view-restaurant-nav.component.html',
  styleUrls: ['./view-restaurant-nav.component.scss']
})
export class ViewRestaurantNavComponent implements OnInit {

  constructor(private routeService: RouteService, private dishService: DishService) { }

  ngOnInit(): void {
  }

  goBackToRestaurant(){
    this.routeService.goToUserDashboard();
    this.clearCart();
  }

  clearCart(){
    this.dishService.clearAllDishFromArray();
  }
}
