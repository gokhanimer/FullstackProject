import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewRestaurantNavComponent } from './view-restaurant-nav.component';

describe('ViewRestaurantNavComponent', () => {
  let component: ViewRestaurantNavComponent;
  let fixture: ComponentFixture<ViewRestaurantNavComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewRestaurantNavComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewRestaurantNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
