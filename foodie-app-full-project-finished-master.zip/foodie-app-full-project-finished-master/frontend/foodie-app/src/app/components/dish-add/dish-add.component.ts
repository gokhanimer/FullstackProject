import { Component, OnInit } from '@angular/core';
import { Dish } from 'src/app/model/dish';
import {DishService} from "../../services/dish.service";

@Component({
  selector: 'app-dish-add',
  templateUrl: './dish-add.component.html',
  styleUrls: ['./dish-add.component.scss']
})
export class DishAddComponent implements OnInit {

  dish: Dish;
  allDishes: Dish[]

  constructor(private dishService: DishService) {
    this.dish = new Dish();
    this.allDishes=[];
  }

  ngOnInit(): void {
  }

  addDishes(id:number){
    this.dishService.addDish(id,this.dish).subscribe((result) => {
      console.warn(result);
    });
    this.dish = new Dish();
  }
  deleteDish(id: number){
    this.dishService.deleteDish(id,this.dish.dishName);
  }

}
