import {Component, OnInit} from '@angular/core';
import {RestaurantService} from "../../services/restaurant.service";
import {Restaurant} from "../../model/restaurant";
import {DishService} from "../../services/dish.service";
import {MdbModalRef, MdbModalService} from "mdb-angular-ui-kit/modal";
import {CartModalComponent} from "../cart-modal/cart-modal.component";
import {Dish} from "../../model/dish";
import {InfoModalRestaurantComponent} from "../info-modal-restaurant/info-modal-restaurant.component";
import {ViewportScroller} from "@angular/common";

@Component({
  selector: 'app-view-restaurant',
  templateUrl: './view-restaurant.component.html',
  styleUrls: ['./view-restaurant.component.scss']
})
export class ViewRestaurantComponent implements OnInit {

  modalRef: MdbModalRef<CartModalComponent> | null = null;

  message: string;

  restaurant: Restaurant;
  restaurantId: string;
  allRest: Array<Restaurant> = [];
  allDishes: Array<Dish> = [];
  dishByAmerica: Array<Dish> = [];
  dishByAsia: Array<Dish> = [];
  dishByItalia: Array<Dish> = [];
  dishByVegan: Array<Dish> = [];
  public searchtext: string = "";

  rating: number;

  constructor(private restaurantService: RestaurantService, private dishService: DishService, private modalService: MdbModalService, private viewportScroller: ViewportScroller) {
  }

  ngOnInit(): void {
    if(sessionStorage.getItem("restaurant") != null){
      this.restaurant = JSON.parse(sessionStorage.getItem("restaurant"));
    }else{
      console.log("Restaurant is missing");
    }
    this.getDishById(this.restaurant.restaurantId);
    this.restaurantService.getRating(this.restaurant.restaurantId).subscribe(fresRating =>{
      this.rating = fresRating;
    })
  }

  getDishById(id: number){
    this.dishService.getDishFromServerByRestaurantId(id).subscribe(menu =>{
      this.allDishes = menu.dishes;
      this.allDishes.forEach(dish => {
        if(dish.category.toLowerCase() == "american"){
          this.dishByAmerica.push(dish);
        }else if(dish.category.toLowerCase() == "asian"){
          this.dishByAsia.push(dish);
        }else if(dish.category.toLowerCase() == "italian"){
          this.dishByVegan.push(dish);
        }else if(dish.category.toLowerCase() == "vegan"){
          this.dishByVegan.push(dish);
        }
      })
    });
  }

  openModal() {
    this.modalRef = this.modalService.open(CartModalComponent, {
      data: { title: 'Shopping cart', dishes: this.allDishes },
    });
  }

  openInfo(){
    this.modalRef = this.modalService.open(InfoModalRestaurantComponent, {
      data: { title: this.restaurant.restaurantName, address: this.restaurant.address, number: this.restaurant.phonenumber, category: this.restaurant.category },
    });
  }

  showDishes(){
    console.log(this.allDishes);
  }

  public onClick(elementId: string): void {
    this.viewportScroller.scrollToAnchor(elementId);
  }

}
