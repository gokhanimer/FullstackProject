import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantOrderViewComponent } from './restaurant-order-view.component';

describe('RestaurantOrderViewComponent', () => {
  let component: RestaurantOrderViewComponent;
  let fixture: ComponentFixture<RestaurantOrderViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RestaurantOrderViewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantOrderViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
