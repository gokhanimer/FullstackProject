import { Component, OnInit } from '@angular/core';
import {Transaction} from "../../model/transaction";
import {TransactionService} from "../../services/transaction.service";
import {RouteService} from "../../services/route.service";
import {Restaurant} from "../../model/restaurant";
import {RestaurantService} from "../../services/restaurant.service";

@Component({
  selector: 'app-restaurant-order-view',
  templateUrl: './restaurant-order-view.component.html',
  styleUrls: ['./restaurant-order-view.component.scss']
})
export class RestaurantOrderViewComponent implements OnInit {


  username: string = "";
  allTrans : Array<Transaction> = [];
  allTransByUsername : Array<Transaction> = [];

  allRest: Array<Restaurant> = [];
  allRestByUname: Array<Restaurant> = [];

  constructor(private transService : TransactionService, private routeService: RouteService, private restService: RestaurantService) {
  }

  ngOnInit(): void {
      this.username = sessionStorage.getItem("username");
      this.restService.getRestaurants().subscribe(allrest => {
          this.allRest = allrest;
          this.allRest.forEach(rest => {
            if(rest.username == this.username){
              this.allRestByUname.push(rest);
            }
          })
        },
        err => {
          console.warn(err);
        });
    this.transService.getAllTransactions().forEach(trans => {
      this.allTrans = trans;
    })

  }

  showAllRest(){
    this.allTrans.forEach(trans => {
      this.allRestByUname.forEach(rest => {
        if(trans.restaurantId == rest.restaurantId){
          this.allTransByUsername.push(trans);
        }
      })
    })
  }

  goBack(){
    this.routeService.goBack();
  }
}

