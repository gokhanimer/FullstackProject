import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Router} from "@angular/router";
import {Restaurant} from "../../model/restaurant";
import {RestaurantService} from "../../services/restaurant.service";
import {Menu} from "../../model/menu";
import {DishService} from "../../services/dish.service";
import {RouteService} from "../../services/route.service";

@Component({
  selector: 'app-restaurant-register',
  templateUrl: './restaurant-register.component.html',
  styleUrls: ['./restaurant-register.component.scss']
})
export class RestaurantRegisterComponent implements OnInit {

  username: string ="";
  restaurantProfile : Restaurant = new Restaurant();
  menu : Menu = new Menu();

  constructor(private httpCli :HttpClient, private route : Router, private restServ: RestaurantService, private dishService: DishService, private routeService: RouteService ) {}
  ngOnInit(): void {
    this.username = sessionStorage.getItem("username");
  }

  registerRestaurant() {
    this.createUniqueId();
    this.restaurantProfile.rating;
    this.restaurantProfile.username = this.username;
    console.log(this.restaurantProfile);
    this.restServ.registerRestaurant(this.restaurantProfile);
    this.menu.restaurantId=this.restaurantProfile.restaurantId;
    this.menu.dishes = [];
    this.dishService.addMenu(this.menu);
    this.route.navigate(['restaurant-dashboard']);
  }

  createUniqueId() {
    this.restaurantProfile.restaurantId =  Math.floor((Math.random() * Date.now())/10598); //The maximum is inclusive and the minimum is inclusive
  }

  goBack(){
    this.routeService.goBack();
  }
}
