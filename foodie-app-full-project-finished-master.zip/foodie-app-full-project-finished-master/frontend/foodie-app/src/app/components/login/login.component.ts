import { Component, OnInit } from '@angular/core';
import {Userprofile} from "../../model/userprofile";
import {RouteService} from "../../services/route.service";
import {AuthenticateService} from "../../services/authenticate.service";
import {UserService} from "../../services/user.service";
import {Restaurant} from "../../model/restaurant";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  users: Object;
  allUsers: Array<Userprofile> = [];

  userprofile : Userprofile = new Userprofile();
  constructor(private myroute: RouteService, private authservice : AuthenticateService, private userService: UserService) {
    this.allUsers =[];
  }

  ngOnInit(): void {
    this.userService.getAllUsers().subscribe(allrest => {
        this.allUsers = allrest
      },
      err => {
        console.warn(err);
      });
  }

  login() {


    this.authservice.generateTokenFromServer(this.userprofile)
      .subscribe(
        (res) => {
          console.log(res);
          sessionStorage.setItem("mytoken", res["mytoken"]);
          const found = this.allUsers.find(user => user.username == this.userprofile.username);
          sessionStorage.setItem("username", found.username);
          console.log(found.status);
          if(found.username.toLowerCase() == "admin"){
            this.myroute.goToAdminDashboard();
          }else if (found.status.toLowerCase() == "restaurant"){
            this.myroute.goToRestaurantDashboard();
          }else if(found.status.toLowerCase() == "user"){
            this.myroute.goToUserDashboard();
          }else {
            this.myroute.goToLogin();
          }
        }
      ),
      (err) =>{console.log(err.error)}
  }

  goToUserRegister(){
    this.myroute.goToUserRegister();
  }

  getAllUsers(){
    this.userService.getAllUsers();
  }
}
