import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {LoginComponent} from "./components/login/login.component";
import {RegisterComponent} from "./components/register/register.component";
import {UserDashboardComponent} from "./components/user-dashboard/user-dashboard.component";
import {RestaurantDashboardComponent} from "./components/restaurant-dashboard/restaurant-dashboard.component";
import {AdminDashboardComponent} from "./components/admin-dashboard/admin-dashboard.component";
import {RestaurantRegisterComponent} from "./components/restaurant-register/restaurant-register.component";
import {FoodieGuard} from "./foodie.guard";
import {RegisterQuestionComponent} from "./components/register-question/register-question.component";
import {LandingsiteComponent} from "./components/landingsite/landingsite.component";
import {UserViewRestaurantComponent} from "./components/user-view-restaurant/user-view-restaurant.component";
import {ViewRestaurantComponent} from "./components/view-restaurant/view-restaurant.component";
import {CartComponent} from "./components/cart/cart.component";
import {ViewAfterOrderingComponent} from "./components/view-after-ordering/view-after-ordering.component";
import {RestaurantOrderViewComponent} from "./components/restaurant-order-view/restaurant-order-view.component";
import {DishViewComponent} from "./components/dish-view/dish-view.component";
import {EditRestaurantComponent} from "./components/edit-restaurant/edit-restaurant.component";
import {RestaurantTransactionsComponent} from "./components/restaurant-transactions/restaurant-transactions.component";

const routes: Routes = [
  {path:'login', component: LoginComponent},
  {path: 'landing-page', component: LandingsiteComponent},
  {path: 'view-restaurant', component: ViewRestaurantComponent},
  {path: 'user-register', component: RegisterComponent},
  {path: 'user-dashboard', component: UserDashboardComponent, canActivate: [FoodieGuard]},
  {path: 'restaurant-dashboard',
    component: RestaurantDashboardComponent,
    canActivate: [FoodieGuard] ,
    children: [
      { path: 'edit/:restaurantId',
        component : EditRestaurantComponent,
        outlet: 'editOutlet'
      }]
  },
  {path: 'restaurant-register', component: RestaurantRegisterComponent},
  {path: 'cart', component: CartComponent},
  {path: 'admin-dashboard', component: AdminDashboardComponent, canActivate: [FoodieGuard]},
  {path: 'register-question', component: RegisterQuestionComponent},
  {path: 'order-view', component: ViewAfterOrderingComponent},
  {path: 'user-view-restaurant', component: UserViewRestaurantComponent, canActivate: [FoodieGuard]},
  {path: 'restaurant-transactions', component : RestaurantTransactionsComponent},
  {path: 'dishes-view-restaurant', component: DishViewComponent, canActivate: [FoodieGuard]},
  {path: '', redirectTo: 'landing-page', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
