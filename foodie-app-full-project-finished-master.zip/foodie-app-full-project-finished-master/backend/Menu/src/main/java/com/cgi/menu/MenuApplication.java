package com.cgi.menu;

import com.cgi.menu.filter.MenuFilter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class MenuApplication {

    public static void main(String[] args) {
        SpringApplication.run(MenuApplication.class, args);
    }

    @Bean
    public FilterRegistrationBean getFilter()
    {

        FilterRegistrationBean fBean=new FilterRegistrationBean();
        fBean.setFilter(new MenuFilter());
        fBean.addUrlPatterns("/Menu/mongo/addMenu");
        fBean.addUrlPatterns("/Menu/mongo/deleteMenu/*");
        fBean.addUrlPatterns("/Menu/mongo/addDish/*");
        fBean.addUrlPatterns("/Menu/mongo/deleteDish/*");
        fBean.addUrlPatterns("/Menu/mongo/updateDish/*");
        return fBean;
    }


}
