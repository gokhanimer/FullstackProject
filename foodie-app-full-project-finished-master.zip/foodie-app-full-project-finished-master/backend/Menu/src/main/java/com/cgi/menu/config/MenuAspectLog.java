package com.cgi.menu.config;

import com.cgi.menu.model.Menu;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

@Aspect
public class MenuAspectLog {

    Logger myLog = LoggerFactory.getLogger(MenuAspectLog.class);


    @Before("execution (* com.cgi.menu.controller.MenuController.addMenu(..))")
    public void beforeSaveLog(JoinPoint jp) {
        myLog.info("Before saving Menu Object");
    }

    @Before("execution (* com.cgi.menu.controller.MenuController.viewAllDishes(..))")
    public void beforeViewAllDishes(JoinPoint jp) {
        myLog.info("Before getting all Menu Objects");
    }

    @Before("execution (* com.cgi.menu.controller.MenuController.updateDish(..))")
    public void beforeUpdateRestaurant(JoinPoint jp) {
        myLog.info("before dish has been updated");
    }

    @Before("execution (* com.cgi.menu.controller.MenuController.deleteMenu(..))")
    public void beforeDeleteMenu(JoinPoint jp) {
        myLog.info("before menu has been deleted");
    }

    @Before("execution (* com.cgi.menu.controller.MenuController.addDish(..))")
    public void beforeAddDish(JoinPoint jp) {
        myLog.info("before Dish has been added");
    }

    @Before("execution (* com.cgi.menu.controller.MenuController.deleteDish(..))")
    public void beforeDeleteDish(JoinPoint jp) {
        myLog.info("before Dish has been deleted");
    }



    @Around("execution (* com.cgi.menu.controller.MenuController.addMenu(..))")
    public Object addNewMenuLog(ProceedingJoinPoint pb) throws Throwable {
        Object obj = pb.proceed();
        try {
            ResponseEntity response = (ResponseEntity) obj;

            Menu menu = (Menu) response.getBody();
            myLog.info("Restaurant id " + menu.getRestaurantId() + " with " + menu.getDishes().toString());
        } catch (Exception e) {
            myLog.warn(String.valueOf(e));
        }
        return obj;
    }

    @After("execution (* com.cgi.menu.controller.MenuController.addMenu(..))")
    public void afterAddMenu(JoinPoint jp) {
        myLog.info("Restaurant has been added");
    }

    @After("execution (* com.cgi.menu.controller.MenuController.deleteMenu(..))")
    public void afterDeleteMenu(JoinPoint jp) {
        myLog.info("Menu has been deleted");
    }

    @After("execution (* com.cgi.menu.controller.MenuController.viewAllDishes(..))")
    public void afterViewAllDishes(JoinPoint jp) {
        myLog.info("All menus has been get");
    }

    @After("execution (* com.cgi.menu.controller.MenuController.updateDish(..))")
    public void afterUpdateRestaurant(JoinPoint jp) {
        myLog.info("Dish has been updated");
    }

    @After("execution (* com.cgi.menu.controller.MenuController.addDish(..))")
    public void afterAddDish(JoinPoint jp) {
        myLog.info("Dish has been added");
    }

    @After("execution (* com.cgi.menu.controller.MenuController.deleteDish(..))")
    public void afterDeleteDish(JoinPoint jp) {
        myLog.info("Dish has been deleted");
    }

}

