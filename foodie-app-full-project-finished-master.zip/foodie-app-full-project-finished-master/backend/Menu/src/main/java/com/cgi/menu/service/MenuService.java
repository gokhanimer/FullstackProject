package com.cgi.menu.service;

import com.cgi.menu.model.Dish;
import com.cgi.menu.model.Menu;
import com.cgi.menu.util.exception.DishAlreadyExists;
import com.cgi.menu.util.exception.DishDoesNotExist;
import com.cgi.menu.util.exception.MenuAlreadyExists;
import com.cgi.menu.util.exception.MenuDoesNotExists;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

public interface MenuService {
   public Menu addMenu(Menu menu) throws MenuAlreadyExists;
   public Menu addDish (int restaurantId, Dish dish) throws MenuDoesNotExists, DishAlreadyExists;
   public boolean deleteDish(int restaurantId, String dishName) throws MenuDoesNotExists, DishDoesNotExist;

   public boolean deleteMenu(int restaurantId) throws MenuDoesNotExists;
   public void updateDish(int restaurantId, Dish dish) throws MenuDoesNotExists, DishDoesNotExist;
   public List<Menu> viewAllDishes();
   public List<Menu> viewDishByCategory(String category);
   public List<Menu> viewDishByAvailability(String availability);
   public Menu viewDishesByRestaurantId(int restaurantId) throws MenuDoesNotExists;



}
