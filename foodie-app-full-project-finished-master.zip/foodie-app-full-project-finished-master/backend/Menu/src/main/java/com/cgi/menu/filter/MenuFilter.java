package com.cgi.menu.filter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.swagger.models.HttpMethod;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class MenuFilter extends GenericFilter {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) servletRequest;
        HttpServletResponse httpResponse = (HttpServletResponse) servletResponse;

        if (httpRequest.getMethod().equalsIgnoreCase(HttpMethod.OPTIONS.name())) {
            filterChain.doFilter(httpRequest, httpResponse);
        } else {
            String headerInfo = httpRequest.getHeader("Authorization");

            System.out.println(headerInfo);
            if ((headerInfo == null) || (!headerInfo.startsWith("Bearer"))) {

                throw new ServletException("JWT Token is missing");
            } else {

                String myToken = headerInfo.substring(7);

                try {
                    JwtParser jwtparser = Jwts.parser().setSigningKey("foodie");
                    Jwt jwtObj = jwtparser.parse(myToken);
                    Claims claimObj = (Claims) jwtObj.getBody();

                    System.out.println("logged in user is " + claimObj.getSubject());

                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    throw new ServletException("invalid token");
                }
            }
            filterChain.doFilter(httpRequest, httpResponse);
        }

    }
}
