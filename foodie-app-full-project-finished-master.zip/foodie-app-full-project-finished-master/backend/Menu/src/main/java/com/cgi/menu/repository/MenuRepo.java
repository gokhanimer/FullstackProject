package com.cgi.menu.repository;

import com.cgi.menu.model.Menu;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MenuRepo extends MongoRepository<Menu,Integer> {

}
