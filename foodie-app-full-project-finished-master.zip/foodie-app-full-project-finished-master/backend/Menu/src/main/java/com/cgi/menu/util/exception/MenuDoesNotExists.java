package com.cgi.menu.util.exception;

public class MenuDoesNotExists extends Exception{

    public MenuDoesNotExists(String s){
        super(s);
    }

}
