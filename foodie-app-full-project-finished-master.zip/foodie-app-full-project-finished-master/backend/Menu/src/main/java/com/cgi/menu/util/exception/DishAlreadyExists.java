package com.cgi.menu.util.exception;

public class DishAlreadyExists extends Exception{

    public DishAlreadyExists(String s){
        super(s);
    }

}
