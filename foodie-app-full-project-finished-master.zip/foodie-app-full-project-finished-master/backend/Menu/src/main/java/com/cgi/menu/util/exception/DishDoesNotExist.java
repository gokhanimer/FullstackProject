package com.cgi.menu.util.exception;

public class DishDoesNotExist extends Exception{
    public DishDoesNotExist(String s){
        super(s);
    }
}
