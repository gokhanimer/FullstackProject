package com.cgi.menu.config;

import com.cgi.menu.MenuApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy
public class MenuAopConfig {

    @Bean
    public MenuAopConfig getAspect()
    {
        return new MenuAopConfig();
    }

}
