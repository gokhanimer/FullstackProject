package com.cgi.menu.util.exception;

public class MenuAlreadyExists extends Exception{

    public MenuAlreadyExists(String s){super(s);}

}
