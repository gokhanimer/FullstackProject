package com.cgi.menu.controller;

import com.cgi.menu.model.Dish;
import com.cgi.menu.model.Menu;
import com.cgi.menu.service.MenuService;
import com.cgi.menu.util.exception.DishAlreadyExists;
import com.cgi.menu.util.exception.DishDoesNotExist;
import com.cgi.menu.util.exception.MenuAlreadyExists;
import com.cgi.menu.util.exception.MenuDoesNotExists;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("Menu/mongo/")
public class MenuController {

    @Autowired
    MenuService menuService;

    @ApiOperation("Add a new Menu for a restaurant")
    @PostMapping("/addMenu")
    public ResponseEntity<?> addMenu(@RequestBody Menu menu) {
        try {

            return new ResponseEntity<>(menuService.addMenu(menu), HttpStatus.OK);

        } catch (MenuAlreadyExists e) {

            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);

        }
    }
    @ApiOperation("Delete a Menu for a restaurant")
    @DeleteMapping("/deleteMenu/{restaurantId}")
    public ResponseEntity<?> deleteMenu(@PathVariable int restaurantId) {
        try {
            return new ResponseEntity<>(menuService.deleteMenu(restaurantId),HttpStatus.OK);

        }catch (MenuDoesNotExists e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }



    @ApiOperation("Add a dish to a restaurant by restaurantID")
    @PostMapping("/addDish/{restaurantId}")
    public ResponseEntity<?> addDish(@PathVariable int restaurantId, @RequestBody Dish dish) {
        try {

            return new ResponseEntity<>(menuService.addDish(restaurantId, dish), HttpStatus.OK);

        } catch (MenuDoesNotExists e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);

        }catch (DishAlreadyExists e) {

            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);

        }
    }

    @ApiOperation("Delete a dish by restaurantId")
    @DeleteMapping("/deleteDish/{restaurantId}")
    public ResponseEntity<?> deleteDish(@PathVariable int restaurantId, @RequestBody String dishName) {

        try {


            return new ResponseEntity<>(menuService.deleteDish(restaurantId, dishName),HttpStatus.OK);

        } catch (MenuDoesNotExists | DishDoesNotExist e) {

            return new ResponseEntity<>(e.getMessage(),  HttpStatus.NOT_FOUND);
        }
    }

    @ApiOperation("Update a dish by restaurantId")
    @PutMapping("/updateDish/{restaurantId}")
    public ResponseEntity<?> updateDish(@PathVariable int restaurantId,@RequestBody  Dish dish){

        try {
            menuService.updateDish(restaurantId, dish);
            return new ResponseEntity<>(HttpStatus.OK);

        } catch (MenuDoesNotExists | DishDoesNotExist e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
        }
    }

    @ApiOperation("View All Dishes across all restaurants")
    @GetMapping("/viewAllDishes")
    public ResponseEntity<?> viewAllDishes(){
        List<Menu> menuList = menuService.viewAllDishes();
        return new ResponseEntity<>(menuList,HttpStatus.OK);
    }

    @ApiOperation("View All Dishes By Category across all restaurants")
    @GetMapping("/viewAllDishesByCategory/{category}")
    public ResponseEntity<?> viewAllDishesByCategory(@PathVariable String category){
        List<Menu> menuList = menuService.viewDishByCategory(category);
        return new ResponseEntity<>(menuList,HttpStatus.OK);
    }

    @ApiOperation("View All Dishes By Category across all restaurants")
    @GetMapping("/viewAllDishesByAvailability/{availability}")
    public ResponseEntity<?> viewAllDishesByAvailability(@PathVariable String availability){
        List<Menu> menuList = menuService.viewDishByAvailability(availability);
        return new ResponseEntity<>(menuList,HttpStatus.OK);
    }

    @ApiOperation("View All Dishes By a Restaurant")
    @GetMapping("/viewDishesByRestaurant/{restaurantId}")
    public ResponseEntity<?> viewDishByRestaurantId(@PathVariable int restaurantId){
        try {
            return new ResponseEntity<>(menuService.viewDishesByRestaurantId(restaurantId),HttpStatus.OK);
        } catch (MenuDoesNotExists e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }

}
