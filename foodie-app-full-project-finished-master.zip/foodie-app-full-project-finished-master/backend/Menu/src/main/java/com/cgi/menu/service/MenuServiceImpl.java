package com.cgi.menu.service;

import com.cgi.menu.model.Dish;
import com.cgi.menu.model.Menu;
import com.cgi.menu.repository.MenuRepo;
import com.cgi.menu.util.exception.DishAlreadyExists;
import com.cgi.menu.util.exception.DishDoesNotExist;
import com.cgi.menu.util.exception.MenuAlreadyExists;
import com.cgi.menu.util.exception.MenuDoesNotExists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class MenuServiceImpl implements MenuService {

    @Autowired
    MenuRepo menuRepo;

    @Override
    public Menu addMenu(Menu menu) throws MenuAlreadyExists {
        System.out.println("add menu  called on: "+menu);
        Optional<Menu> optionalMenu = menuRepo.findById(menu.getRestaurantId());
        if (optionalMenu.isEmpty()) {
            menuRepo.save(menu);
            return menu;

        }
        throw new MenuAlreadyExists("A Menu for this restaurant already exist");
    }

    @Override
    public Menu addDish(int restaurantId, Dish dish) throws MenuDoesNotExists, DishAlreadyExists {

        Optional<Menu> optionalMenu = menuRepo.findById(restaurantId);

        if (optionalMenu.isEmpty()) {
            throw new MenuDoesNotExists("The Menu does not currently exists");
        }

        Menu newMenu = optionalMenu.get();
        List<Dish> dishes = newMenu.getDishes();

        if (dishes.contains(dish)) {
            throw new DishAlreadyExists("This Dish already exists");
        }

        dishes.add(dish);
        newMenu.setDishes(dishes);
        menuRepo.save(newMenu);
        return newMenu;
    }

    @Override
    public boolean deleteDish(int restaurantId, String dishName) throws MenuDoesNotExists, DishDoesNotExist {
        Optional<Menu> optionalMenu = menuRepo.findById(restaurantId);

        if (optionalMenu.isEmpty()) {
            throw new MenuDoesNotExists("The Menu does not currently exists");
        }

        Menu newMenu = optionalMenu.get();
        List<Dish> dishes = newMenu.getDishes();

        for (Dish dish: dishes) {
            if(dishName.contains(dish.getDishName())){
                dishes.remove(dish);
                newMenu.setDishes(dishes);
                menuRepo.save(newMenu);
                return true;
            }
        }
        throw new DishDoesNotExist("The Dish does not exists");
    }

    @Override
    public boolean deleteMenu(int restaurantId) throws MenuDoesNotExists {

        Optional<Menu> optionalMenu = menuRepo.findById(restaurantId);

        if (optionalMenu.isEmpty()) {
            throw new MenuDoesNotExists("The Menu does not exist");
        }
        menuRepo.delete(optionalMenu.get());
        return true;
    }

    @Override
    public void updateDish(int restaurantId, Dish dish) throws MenuDoesNotExists, DishDoesNotExist {
        Optional<Menu> optionalMenu = menuRepo.findById(restaurantId);

        if (optionalMenu.isEmpty()) {
            throw new MenuDoesNotExists("The Menu does not currently exists");
        }

        Menu newMenu = optionalMenu.get();
        List<Dish> dishes = newMenu.getDishes();

        if (!dishes.contains(dish)) {
            throw new DishDoesNotExist("The Dish does not exist");
        }

        dishes.remove(dish);
        dishes.add(dish);
        newMenu.setDishes(dishes);
        menuRepo.save(newMenu);
    }

    @Override
    public List<Menu> viewAllDishes() {
        return menuRepo.findAll();
    }

    @Override
    public List<Menu> viewDishByCategory(String category) {
        List<Menu> menuList = menuRepo.findAll();
        List<Menu> newMenuList = new ArrayList<>();
        for (Menu menu : menuList) {
            List<Dish> newDishList = new ArrayList<>();
            for (Dish dish : menu.getDishes()) {
                if (dish.getCategory().equals(category)) {
                    newDishList.add(dish);
                }
            }
            if (newDishList.size() > 0) {
                Menu modifiedMenu = new Menu();
                modifiedMenu.setRestaurantId(menu.getRestaurantId());
                modifiedMenu.setDishes(newDishList);
                newMenuList.add(modifiedMenu);
            }
        }

        return newMenuList;
    }

    @Override
    public List<Menu> viewDishByAvailability(String availability) {
        List<Menu> menuList = menuRepo.findAll();
        List<Menu> newMenuList = new ArrayList<>();

        for (Menu menu : menuList) {
            List<Dish> newDishList = new ArrayList<>();
            for (Dish dish : menu.getDishes()) {
                if (dish.getAvailability().equals(availability)) {
                    newDishList.add(dish);
                }
            }
            if (newDishList.size() > 0) {
                Menu modifiedMenu = new Menu();
                modifiedMenu.setRestaurantId(menu.getRestaurantId());
                modifiedMenu.setDishes(newDishList);
                newMenuList.add(modifiedMenu);
            }
        }
        return newMenuList;
    }

    @Override
    public Menu viewDishesByRestaurantId(int restaurantId) throws MenuDoesNotExists {
        Optional<Menu> optionalMenu = menuRepo.findById(restaurantId);
        if (optionalMenu.isEmpty()) {
            throw new MenuDoesNotExists("Menu does not exist");
        }
        return optionalMenu.get();
    }
}
