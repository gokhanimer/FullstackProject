package com.cgi.menu.controller;


import com.cgi.menu.model.Dish;
import com.cgi.menu.model.Menu;
import com.cgi.menu.service.MenuService;
import com.cgi.menu.util.exception.DishAlreadyExists;
import com.cgi.menu.util.exception.DishDoesNotExist;
import com.cgi.menu.util.exception.MenuAlreadyExists;
import com.cgi.menu.util.exception.MenuDoesNotExists;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest
public class MenuControllerTest {

    @Autowired
    MockMvc mockMvc;

    @InjectMocks
    MenuController menuController;

    @MockBean
    MenuService menuService;

    Menu menu;

    Dish durum;
    Dish pizza;

    List<Menu> menus;



    @Before
    public void setUp(){
        MockitoAnnotations.openMocks(this);

        mockMvc = MockMvcBuilders.standaloneSetup(menuController).build();

        List<String> ingredients = new ArrayList<>();
        List<Dish> dishes = new ArrayList<>();
        menus = new ArrayList<>();


        //One Menu for 1 restaurant with 2 dishes...

        ingredients.add("Tomato");
        ingredients.add("Cheese");
        ingredients.add("Basil");

        pizza = new Dish();
        pizza.setDishName("Pizza");
        pizza.setPrice(10.3);
        pizza.setCategory("Italian");
        pizza.setAvailability("Noon");
        pizza.setIngredients(ingredients);

        dishes.add(pizza);

        ingredients.clear();
        ingredients.add("Kebab");
        ingredients.add("Salad");
        ingredients.add("Tomato");
        ingredients.add("Dressing");


        durum = new Dish();
        durum.setDishName("Durum");
        durum.setPrice(7.3);
        durum.setCategory("Middle-eastern");
        durum.setAvailability("Noon");
        durum.setIngredients(ingredients);

        //dishes.add(durum);


        menu = new Menu();
        menu.setRestaurantId(1);
        menu.setDishes(dishes);

        menus.add(menu);
    }

    @Test
    public void addMenuSuccess() throws Exception{
        when(menuService.addMenu(menu)).thenReturn(menu);

        mockMvc.perform(post("/Menu/mongo/addMenu")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(convertToJson(menu)))
                .andExpect(status().isOk());

    }
    @Test
    public void addMenuFail() throws Exception{
        when(menuService.addMenu(any())).thenThrow(MenuAlreadyExists.class);

        mockMvc.perform(post("/Menu/mongo/addMenu")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(convertToJson(menu)))
                .andExpect(status().isConflict()).andDo(MockMvcResultHandlers.print());

    }

    @Test
    public void deleteMenuSuccess() throws Exception{
        when(menuService.deleteMenu(1)).thenReturn(true);

        mockMvc.perform(delete("/Menu/mongo/deleteMenu/1"))
                .andExpect(status().isOk()).andDo(MockMvcResultHandlers.print());
    }

    @Test
    public void deleteMenuFail() throws Exception{
        when(menuService.deleteMenu(anyInt())).thenThrow(MenuDoesNotExists.class);

        mockMvc.perform(delete("/Menu/mongo/deleteMenu/1"))
                .andExpect(status().isNotFound()).andDo(MockMvcResultHandlers.print());
    }

    @Test
    public void addDishSuccess() throws Exception{
        when(menuService.addDish(1,durum)).thenReturn(menu);

        mockMvc.perform(post("/Menu/mongo/addDish/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(convertToJson(durum)))
                .andExpect(status().isOk());

    }
    @Test
    public void addDishDoesAlreadyExistFAIL() throws Exception{
        when(menuService.addDish(anyInt(),any())).thenThrow(DishAlreadyExists.class);

        mockMvc.perform(post("/Menu/mongo/addDish/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(convertToJson(menu)))
                .andExpect(status().isConflict()).andDo(MockMvcResultHandlers.print());

    }

    @Test
    public void addDishMenuDoesNotExistFail() throws Exception{
        when(menuService.addDish(anyInt(),any())).thenThrow(MenuDoesNotExists.class);

        mockMvc.perform(post("/Menu/mongo/addDish/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(convertToJson(menu)))
                .andExpect(status().isNotFound()).andDo(MockMvcResultHandlers.print());
    }

    @Test
    public void deleteDishSuccess() throws Exception{
        when(menuService.deleteDish(1,pizza.getDishName())).thenReturn(true);

        mockMvc.perform(delete("/Menu/mongo/deleteDish/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(convertToJson(pizza.getDishName())))
                .andExpect(status().isOk());
    }

    @Test
    public void deleteDishDoesNotExistFAIL() throws Exception{
        when(menuService.deleteDish(anyInt(),anyString())).thenThrow(DishDoesNotExist.class);

        mockMvc.perform(delete("/Menu/mongo/deleteDish/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(convertToJson(pizza.getDishName())))
                .andExpect(status().isNotFound()).andDo(MockMvcResultHandlers.print());

    }

    @Test
    public void getAllMenus() throws Exception {
        when(menuService.viewAllDishes()).thenReturn(menus);

        mockMvc.perform(
                MockMvcRequestBuilders.get("/Menu/mongo/viewAllDishes")
        )
                .andExpect(status().isOk());
    }

    @Test
    public void getAllMenusByCategory() throws Exception {
        when(menuService.viewDishByCategory("Italian")).thenReturn(menus);

        mockMvc.perform(MockMvcRequestBuilders.get("/Menu/mongo/viewAllDishesByCategory/Italian"))
                .andExpect(status().isOk());
    }

    @Test
    public void getAllMenusByAvailability() throws Exception {
        when(menuService.viewDishByCategory("Noon")).thenReturn(menus);

        mockMvc.perform(MockMvcRequestBuilders.get("/Menu/mongo/viewAllDishesByAvailability/Noon"))
                .andExpect(status().isOk());
    }

    @Test
    public void getAllDishesByRestaurantId() throws Exception {
        when(menuService.viewDishesByRestaurantId(1)).thenReturn(menu);

        mockMvc.perform(MockMvcRequestBuilders.get("/Menu/mongo/viewDishesByRestaurant/1"))
                .andExpect(status().isOk());
    }



    public String convertToJson (Object obj) throws JsonProcessingException {
        ObjectMapper objMap = new ObjectMapper();
        return objMap.writeValueAsString(obj);
    }
}
