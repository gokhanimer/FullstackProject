package com.cgi.menu.service;


import com.cgi.menu.model.Dish;
import com.cgi.menu.model.Menu;
import com.cgi.menu.repository.MenuRepo;
import com.cgi.menu.util.exception.DishAlreadyExists;
import com.cgi.menu.util.exception.DishDoesNotExist;
import com.cgi.menu.util.exception.MenuAlreadyExists;
import com.cgi.menu.util.exception.MenuDoesNotExists;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


public class MenuServiceTest {

    @InjectMocks
    private MenuServiceImpl menuService;
    @Mock
    private MenuRepo menuRepo;


    Menu menu;

    Dish pizza;
    Dish durum;


    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        List<String> ingredients = new ArrayList<>();
        List<Dish> dishes = new ArrayList<>();


        //One Menu for 1 restaurant with 2 dishes...

        ingredients.add("Tomato");
        ingredients.add("Cheese");
        ingredients.add("Basil");

        pizza = new Dish();
        pizza.setDishName("Pizza");
        pizza.setPrice(10.3);
        pizza.setCategory("Italian");
        pizza.setAvailability("Noon");
        pizza.setIngredients(ingredients);

        dishes.add(pizza);

        ingredients.clear();
        ingredients.add("Kebab");
        ingredients.add("Salad");
        ingredients.add("Tomato");
        ingredients.add("Dressing");


        durum = new Dish();
        durum.setDishName("Durum");
        durum.setPrice(7.3);
        durum.setCategory("Middle-eastern");
        durum.setAvailability("Noon");
        durum.setIngredients(ingredients);

        menu = new Menu();
        menu.setRestaurantId(1);
        menu.setDishes(dishes);
    }

    @Test
    public void addMenuTestSuccess() throws MenuAlreadyExists {
        Mockito.when(menuRepo.save(menu)).thenReturn(menu);

        Menu menuResult = menuService.addMenu(menu);

        assertEquals(menuResult.getRestaurantId(),1);

    }

    @Test
    public void addMenuAndThrowsExceptionTest() throws MenuAlreadyExists {

        Optional<Menu> optionalMenu = Optional.of(menu);


        Mockito.when(menuRepo.findById(1)).thenReturn(optionalMenu);


        assertThrows(MenuAlreadyExists.class , ()-> menuService.addMenu(menu));



        verify(menuRepo,times(0)).save(menu);
    }

    @Test
    public void deleteMenuTestSuccess() throws Exception {
        Optional<Menu> optionalMenu = Optional.of(menu);
        Mockito.when(menuRepo.findById(1)).thenReturn(optionalMenu);
        doNothing().when(menuRepo).delete(menu);

        menuService.deleteMenu(1);

        verify(menuRepo,times(1)).delete(menu);

    }

    @Test
    public void deleteMenuDoesNotExistException() throws Exception {
        Optional<Menu> optionalMenu = Optional.empty();
        Mockito.when(menuRepo.findById(2)).thenReturn(optionalMenu);

        MenuDoesNotExists thrown = assertThrows(
                MenuDoesNotExists.class,
                () -> menuService.deleteMenu(2),
                "Expected doThing() to throw, but it didn't"
        );
        System.out.println(thrown.getMessage());
        assertTrue(thrown.getMessage().contains("The Menu does not exist"));

    }

    @Test
    public void addDishTestSuccess() throws MenuDoesNotExists, DishAlreadyExists {
        assertFalse(menu.getDishes().contains(durum));

        Optional<Menu> optionalMenu = Optional.of(menu);
        Mockito.when(menuRepo.findById(1)).thenReturn(optionalMenu);
        Mockito.when(menuRepo.save(menu)).thenReturn(menu);

        Menu menuResult = menuService.addDish(1,durum);

        assertTrue(menuResult.getDishes().contains(durum));

    }

    @Test
    public void addDishAndMenuDoesNotExistExceptionTest() throws MenuDoesNotExists {
        Optional<Menu> optionalMenu = Optional.empty();
        Mockito.when(menuRepo.findById(2)).thenReturn(optionalMenu);

        MenuDoesNotExists thrown = assertThrows(
                MenuDoesNotExists.class,
                () -> menuService.addDish(2,durum),
                "Expected doThing() to throw, but it didn't"
        );
        System.out.println(thrown.getMessage());
        assertTrue(thrown.getMessage().contains("The Menu does not currently exists"));
    }

    @Test
    public void addDishAndDishDoesAlreadyExistExceptionTest() throws Exception {
        List<Dish> dishList = menu.getDishes();
        dishList.add(durum);
        menu.setDishes(dishList);
        Optional<Menu> optionalMenu = Optional.of(menu);
        Mockito.when(menuRepo.findById(1)).thenReturn(optionalMenu);

        DishAlreadyExists thrown = assertThrows(
                DishAlreadyExists.class,
                () -> menuService.addDish(1,durum),
                "Expected doThing() to throw, but it didn't"
        );
        System.out.println(thrown.getMessage());
        assertTrue(thrown.getMessage().contains("This Dish already exists"));

    }

    @Test
    public void deleteDishTestSuccess() throws Exception {
        Optional<Menu> optionalMenu = Optional.of(menu);
        Mockito.when(menuRepo.findById(1)).thenReturn(optionalMenu);

       boolean menuResult = menuService.deleteDish(1,pizza.getDishName());

        assertTrue(menuResult);

    }

    @Test
    public void deleteDishFAILMenuDoesNotExistExceptionTest() throws MenuDoesNotExists {
        Optional<Menu> optionalMenu = Optional.empty();
        Mockito.when(menuRepo.findById(2)).thenReturn(optionalMenu);

        MenuDoesNotExists thrown = assertThrows(
                MenuDoesNotExists.class,
                () -> menuService.addDish(2,durum),
                "Expected doThing() to throw, but it didn't"
        );
        System.out.println(thrown.getMessage());
        assertTrue(thrown.getMessage().contains("The Menu does not currently exists"));
    }


    @Test
    public void deleteDishDoesNotExistException() throws Exception {
        Optional<Menu> optionalMenu = Optional.of(menu);
        Mockito.when(menuRepo.findById(1)).thenReturn(optionalMenu);

        DishDoesNotExist thrown = assertThrows(
                DishDoesNotExist.class,
                () -> menuService.deleteDish(1,durum.getDishName()),
                "Expected doThing() to throw, but it didn't"
        );
        System.out.println(thrown.getMessage());
        assertTrue(thrown.getMessage().contains("The Dish does not exists"));
    }

}
