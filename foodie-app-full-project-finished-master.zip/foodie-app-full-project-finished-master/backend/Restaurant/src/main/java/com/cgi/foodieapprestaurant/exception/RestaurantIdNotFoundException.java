package com.cgi.foodieapprestaurant.exception;

public class RestaurantIdNotFoundException extends Exception{
    public RestaurantIdNotFoundException(String nm) {super(nm);}
}
