package com.cgi.foodieapprestaurant.repository;

import com.cgi.foodieapprestaurant.model.Restaurant;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RestaurantRepo extends MongoRepository<Restaurant, Integer> {

    Restaurant findRestaurantByCity(String city);
    List<Restaurant> findRestaurantByRating(int rating);
    List<Restaurant> findRestaurantByUsername(String username);
    List<Restaurant> findRestaurantByApprovalStatus(boolean approvalstatus);

}
