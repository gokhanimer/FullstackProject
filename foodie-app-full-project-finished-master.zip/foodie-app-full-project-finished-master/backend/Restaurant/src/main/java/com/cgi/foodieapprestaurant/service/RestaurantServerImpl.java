package com.cgi.foodieapprestaurant.service;

import com.cgi.foodieapprestaurant.exception.RestaurantIdAlreadyExistsException;
import com.cgi.foodieapprestaurant.exception.RestaurantIdNotFoundException;
import com.cgi.foodieapprestaurant.exception.UserNameHasAlreadyRatedThisRestaurant;
import com.cgi.foodieapprestaurant.model.Restaurant;
import com.cgi.foodieapprestaurant.repository.RestaurantRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RestaurantServerImpl implements RestaurantService {

    @Autowired
    RestaurantRepo restRepo;

    @Override
    public Restaurant addRestaurant(Restaurant restaurantObj) throws RestaurantIdAlreadyExistsException {
        Optional<Restaurant> optionalRestaurant = restRepo.findById(restaurantObj.getRestaurantId());
        if(optionalRestaurant.isPresent()){
            throw new RestaurantIdAlreadyExistsException("Restaurant already exists");
        }else{
            restRepo.save(restaurantObj);
            return restaurantObj;
        }
    }

    @Override
    public List<Restaurant> getRestaurants() {
        return restRepo.findAll();
    }

    @Override
    public boolean deleteRestaurant(int restaurantId) {
        Optional<Restaurant> optionalRestaurant = restRepo.findById(restaurantId);
        if(optionalRestaurant.isPresent()){
            restRepo.deleteById(restaurantId);
            return true;
        }else{
            return false;
        }
    }

    @Override
    public Restaurant updateRestaurant(Restaurant restaurantObj) throws RestaurantIdNotFoundException {
        Optional<Restaurant> restaurantOptional =restRepo.findById(restaurantObj.getRestaurantId());
        if(restaurantOptional.isPresent()){
            restRepo.save(restaurantObj);
            return restaurantObj;
        }
        return null;
    }

    @Override
    public float getRating(int restaurantId) throws RestaurantIdNotFoundException {
        Optional<Restaurant> restaurantOptional = restRepo.findById(restaurantId);
        if(restaurantOptional.isPresent()){
            Restaurant updatedRestaurant = restaurantOptional.get();
            float sumRating = 0;
            for (float f: updatedRestaurant.getRating().values()){
                sumRating=sumRating+f;
            }
            return sumRating/updatedRestaurant.getRating().size();
        }
        else {
            throw new RestaurantIdNotFoundException("Id not found");
        }
    }

    @Override
    public float updateRating(int restaurantId, int rating, String userName) throws RestaurantIdNotFoundException, UserNameHasAlreadyRatedThisRestaurant {
        Optional<Restaurant> restaurantOptional = restRepo.findById(restaurantId);
        if(restaurantOptional.isEmpty()){
            throw new RestaurantIdNotFoundException("Id not found");
        }

        Restaurant updatedRestaurant = restaurantOptional.get();

        if(updatedRestaurant.getRating().containsKey(userName)){
            throw new UserNameHasAlreadyRatedThisRestaurant("User Has Already Rated This Restaurant");
        }
        updatedRestaurant.addRating(userName,rating);
        restRepo.save(updatedRestaurant);

        float sumRating = 0;
        for (float f: updatedRestaurant.getRating().values()){
            sumRating=sumRating+f;
        }
        return sumRating/updatedRestaurant.getRating().size();
    }

    @Override
    public Restaurant updateApprovalStatus(int restaurantId, boolean approvalStatus) throws RestaurantIdNotFoundException {
        Optional<Restaurant> restaurantOptional = restRepo.findById(restaurantId);
        if(restaurantOptional.isEmpty()){
            throw new RestaurantIdNotFoundException("Id not found");
        }

        Restaurant updatedRestaurant = restaurantOptional.get();
        updatedRestaurant.setApprovalStatus(approvalStatus);
        restRepo.save(updatedRestaurant);
        return updatedRestaurant;
    }

    @Override
    public Restaurant viewRestaurantsByCity(String city) {
        return restRepo.findRestaurantByCity(city);
    }

    @Override
    public List<Restaurant> viewRestaurantByRating(int rating) {
        return restRepo.findRestaurantByRating(rating);
    }

    @Override
    public List<Restaurant> viewRestaurantByUsername(String username) { return restRepo.findRestaurantByUsername(username); }

    @Override
    public List<Restaurant> viewRestaurantByApprovalStatus(boolean approvalstatus) { return restRepo.findRestaurantByApprovalStatus(approvalstatus);}
}
