package com.cgi.foodieapprestaurant.exception;

public class RestaurantIdAlreadyExistsException extends Exception {
    public RestaurantIdAlreadyExistsException(String nm) {super(nm);}
}
