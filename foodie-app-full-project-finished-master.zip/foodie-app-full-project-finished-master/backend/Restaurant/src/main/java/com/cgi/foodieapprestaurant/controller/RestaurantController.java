package com.cgi.foodieapprestaurant.controller;

import com.cgi.foodieapprestaurant.exception.RestaurantIdAlreadyExistsException;
import com.cgi.foodieapprestaurant.exception.RestaurantIdNotFoundException;
import com.cgi.foodieapprestaurant.exception.UserNameHasAlreadyRatedThisRestaurant;
import com.cgi.foodieapprestaurant.model.Restaurant;
import com.cgi.foodieapprestaurant.service.RestaurantService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/restaurant")
public class RestaurantController {

    @Autowired
    RestaurantService restaurantService;

    @ApiOperation("Adding restaurant")
    @PostMapping("/addRestaurant")
    public ResponseEntity<?> saveRestaurant(@RequestBody Restaurant restaurantObj){
        Restaurant restResult;
        try{
            restResult = restaurantService.addRestaurant(restaurantObj);
            return new ResponseEntity<Restaurant>(restResult, HttpStatus.CREATED);
        }catch(RestaurantIdAlreadyExistsException e){
            return new ResponseEntity<String>(e.getMessage(),HttpStatus.CONFLICT);
        }
    }

    @ApiOperation("Get all restaurants")
    @GetMapping("/getRestaurant")
    public ResponseEntity<?> getRestaurants(){
        List<Restaurant> restaurants = restaurantService.getRestaurants();
        return new ResponseEntity<List<Restaurant>>(restaurants, HttpStatus.OK);
    }

    @ApiOperation("Delete restaurant")
    @DeleteMapping("/deleteRestaurant/{restid}")
    public ResponseEntity<?> delete(@PathVariable("restid") int rid) {
        boolean result = restaurantService.deleteRestaurant(rid);
        if(result){
            return new ResponseEntity<String>("Deleted successfully", HttpStatus.OK);
        }else{
            return new ResponseEntity<String>("Id not found", HttpStatus.NOT_FOUND);
        }
    }

    @ApiOperation("Update restaurant")
    @PutMapping("/update")
    public ResponseEntity<?> updateRestaurant(@RequestBody Restaurant updRest){
        Restaurant updRestaurant;
        try{
            updRestaurant = restaurantService.updateRestaurant(updRest);
            return new ResponseEntity<Restaurant>(updRestaurant, HttpStatus.ACCEPTED);
        }catch(RestaurantIdNotFoundException e){
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.CONFLICT);
        }
    }

    @ApiOperation("")
    @PutMapping("/updateRating/{restaurantId},{userName},{rating}")
    public ResponseEntity<?> updateRating(@PathVariable("restaurantId") Integer restaurantId, @PathVariable("userName") String userName,@PathVariable("rating") Integer rating) throws RestaurantIdNotFoundException, UserNameHasAlreadyRatedThisRestaurant {
        System.out.println(userName+" is updating rating: "+rating);
        float avgRating;
        try{
            avgRating = restaurantService.updateRating(restaurantId,rating,userName);
            return new ResponseEntity<Float>(avgRating, HttpStatus.OK);
        }catch(RestaurantIdNotFoundException e){
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (UserNameHasAlreadyRatedThisRestaurant e) {
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.ALREADY_REPORTED);
        }
    }

    @ApiOperation("")
    @GetMapping("/getRating/{restaurantId}")
    public ResponseEntity<?> getRating(@PathVariable("restaurantId") Integer restaurantId) throws RestaurantIdNotFoundException, UserNameHasAlreadyRatedThisRestaurant {
        float avgRating;
        try{
            avgRating = restaurantService.getRating(restaurantId);
            return new ResponseEntity<Float>(avgRating, HttpStatus.OK);
        }catch(RestaurantIdNotFoundException e){
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @ApiOperation("Update approvalstatus")
    @PutMapping("/updateApprovalStatus/{restaurantId},{approvalStatus}")
    public ResponseEntity<?> updateApprovalStatus(@PathVariable("restaurantId") int restaurantId, @PathVariable("approvalStatus") boolean approvalStatus) throws RestaurantIdNotFoundException {
        Restaurant updatedRatingRestaurant;
        try{
            updatedRatingRestaurant = restaurantService.updateApprovalStatus(restaurantId, approvalStatus);
            return new ResponseEntity<Restaurant>(updatedRatingRestaurant, HttpStatus.OK);
        }catch(RestaurantIdNotFoundException e){
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @ApiOperation("Get restaurants by city")
    @GetMapping("/getByCity/{city}")
    public ResponseEntity<?> getByCity(@PathVariable("city") String city){
        Restaurant restaurant = restaurantService.viewRestaurantsByCity(city);
        if(restaurant == null){
            return new ResponseEntity<String>("Cannot find city", HttpStatus.NOT_FOUND);
        }else{
            return new ResponseEntity<Restaurant>(restaurant, HttpStatus.FOUND);
        }
    }

    @ApiOperation("Get restaurants by rating")
    @GetMapping("/getByRating/{rating}")
    public ResponseEntity<?> getByRating(@PathVariable("rating") int rating){
        List<Restaurant> restaurant = restaurantService.viewRestaurantByRating(rating);
        if(restaurant.isEmpty()){
            return new ResponseEntity<String>("Cannot find rating", HttpStatus.NOT_FOUND);
        }else{
            return new ResponseEntity<List<Restaurant>>(restaurant, HttpStatus.FOUND);
        }
    }

    @ApiOperation("Get restaurants by username")
    @GetMapping("/getByUsername/{username}")
    public ResponseEntity<?> getByUsername(@PathVariable("username") String username){
        List<Restaurant> restaurant = restaurantService.viewRestaurantByUsername(username);
        if(restaurant.isEmpty()){
            return new ResponseEntity<String>("Cannot find rating", HttpStatus.NOT_FOUND);
        }else{
            return new ResponseEntity<List<Restaurant>>(restaurant, HttpStatus.FOUND);
        }
    }

    @ApiOperation("Get restaurants by approvalstatus")
    @GetMapping("/getByApprovalStatus/{approvalstatus}")
    public ResponseEntity<?> getByApprovalStatus(@PathVariable("approvalstatus") boolean approvalstatus){
        List<Restaurant> restaurant = restaurantService.viewRestaurantByApprovalStatus(approvalstatus);
        if(restaurant.isEmpty()){
            return new ResponseEntity<String>("Cannot find approvalstatus", HttpStatus.NOT_FOUND);
        }else{
            return new ResponseEntity<List<Restaurant>>(restaurant, HttpStatus.OK);
        }
    }


}
