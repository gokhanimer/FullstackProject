package com.cgi.foodieapprestaurant.service;

import com.cgi.foodieapprestaurant.exception.RestaurantIdAlreadyExistsException;
import com.cgi.foodieapprestaurant.exception.RestaurantIdNotFoundException;
import com.cgi.foodieapprestaurant.exception.UserNameHasAlreadyRatedThisRestaurant;
import com.cgi.foodieapprestaurant.model.Restaurant;

import java.util.List;

public interface RestaurantService {

    public Restaurant addRestaurant(Restaurant restaurantObj) throws RestaurantIdAlreadyExistsException;

    public List<Restaurant> getRestaurants();

    public boolean deleteRestaurant(int restaurantId);

    public Restaurant updateRestaurant(Restaurant restaurantObj) throws RestaurantIdNotFoundException;

    float updateRating(int restaurantId, int rating, String userName) throws RestaurantIdNotFoundException, UserNameHasAlreadyRatedThisRestaurant;

    public Restaurant updateApprovalStatus(int restaurantId, boolean approvalStatus) throws RestaurantIdNotFoundException;

    public Restaurant viewRestaurantsByCity (String city);

    public List<Restaurant> viewRestaurantByRating(int rating);

    public float getRating(int restaurantId) throws RestaurantIdNotFoundException;

    public List<Restaurant> viewRestaurantByUsername(String username);

    public List<Restaurant> viewRestaurantByApprovalStatus(boolean approvalstatus);

}
