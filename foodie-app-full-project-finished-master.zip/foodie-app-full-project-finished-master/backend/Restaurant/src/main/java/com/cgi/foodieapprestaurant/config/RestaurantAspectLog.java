package com.cgi.foodieapprestaurant.config;

import com.cgi.foodieapprestaurant.model.Restaurant;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

@Aspect
public class RestaurantAspectLog {

    Logger mylog = LoggerFactory.getLogger(RestaurantAspectLog.class);


    @Before("execution (* com.cgi.foodieapprestaurant.controller.RestaurantController.saveRestaurant(..))")
    public void beforesavelog(JoinPoint jp) { mylog.info("Before saving Restaurant Object");}

    @Before("execution (* com.cgi.foodieapprestaurant.controller.RestaurantController.getRestaurants(..))")
    public void beforegetallobjectlog(JoinPoint jp) { mylog.info("Before getting all Restaurant Objects");}

    @Around("execution (* com.cgi.foodieapprestaurant.controller.RestaurantController.saveRestaurant(..))")
    public Object addnewrestaurantlog(ProceedingJoinPoint pb) throws Throwable
    {
        Object obj=pb.proceed();
        try
        {
            ResponseEntity response=(ResponseEntity)  obj;

            Restaurant restaurantObject =(Restaurant) response.getBody();
            mylog.info("Restaurant id " + restaurantObject.getRestaurantId() + " with name " + restaurantObject.getRestaurantName() + " is getting stored");
        }
        catch(Exception e)
        {
            mylog.warn(String.valueOf(e));
        }
        return obj;
    }

    @After("execution (* com.cgi.foodieapprestaurant.controller.RestaurantController.saveRestaurant(..))")
    public void afteraddedrestaurant(JoinPoint jp) { mylog.info("Restaurant has been added");}

    @After("execution (* com.cgi.foodieapprestaurant.controller.RestaurantController.getRestaurants(..))")
    public void aftergetallrestaurant(JoinPoint jp) { mylog.info("All restaurants has been get");}

    @After("execution (* com.cgi.foodieapprestaurant.controller.RestaurantController.updateRestaurant(..))")
    public void afterupdaterestaurant(JoinPoint jp) { mylog.info("Restaurant has been updated");}

    @After("execution (* com.cgi.foodieapprestaurant.controller.RestaurantController.delete(..))")
    public void afterdeleterestaurant(JoinPoint jp) { mylog.info("Restaurant has been deleted");}


}
