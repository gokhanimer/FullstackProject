package com.cgi.foodieapprestaurant;



import com.cgi.foodieapprestaurant.filter.RestaurantFilter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class FoodieappRestaurantApplication {

    public static void main(String[] args) {
        SpringApplication.run(FoodieappRestaurantApplication.class, args);
    }

    @Bean
    public FilterRegistrationBean getFilter()
    {

        FilterRegistrationBean fbean=new FilterRegistrationBean();
        fbean.setFilter(new RestaurantFilter());
        fbean.addUrlPatterns("/restaurant/deleteRestaurant/*");
        fbean.addUrlPatterns("/restaurant/getRestaurant");
        fbean.addUrlPatterns("/restaurant/getByCity/*");
        fbean.addUrlPatterns("/restaurant/getByRating/*");
        return fbean;
    }

}
