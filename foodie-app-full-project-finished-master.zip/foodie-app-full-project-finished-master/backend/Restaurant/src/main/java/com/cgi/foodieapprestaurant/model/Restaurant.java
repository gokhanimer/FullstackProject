package com.cgi.foodieapprestaurant.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.HashMap;


@Document
public class Restaurant {

    @Id
    private int restaurantId;

    private String restaurantName;
    private String username;
    private String category;
    private String address;
    private int phonenumber;
    private String image;
    private String city;
    private boolean approvalStatus = false;
    private HashMap<String,Integer> rating = new HashMap<String, Integer>();

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(int restaurantId) {
        this.restaurantId = restaurantId;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(int phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public boolean isApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(boolean approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String name) {
        this.restaurantName = name;
    }

    public HashMap<String, Integer> getRating() {
        return rating;
    }

    public void setRating(HashMap<String, Integer> rating) {
        this.rating = rating;
    }

    public void addRating(String username, int rating){
        this.rating.put(username,rating);
    }

    @Override
    public String toString() {
        return "Restaurant{" +
                "restaurantId=" + restaurantId +
                ", restaurantName='" + restaurantName + '\'' +
                ", username='" + username + '\'' +
                ", category='" + category + '\'' +
                ", address='" + address + '\'' +
                ", phonenumber=" + phonenumber +
                ", image='" + image + '\'' +
                ", city='" + city + '\'' +
                ", approvalStatus=" + approvalStatus +
                ", rating=" + rating +
                '}';
    }
}
