package com.cgi.foodieapprestaurant.exception;

public class UserNameHasAlreadyRatedThisRestaurant extends Exception{
    public UserNameHasAlreadyRatedThisRestaurant(String nm) {super(nm);
    }
}
