package com.cgi.foodieapprestaurant.service;

import com.cgi.foodieapprestaurant.exception.RestaurantIdAlreadyExistsException;
import com.cgi.foodieapprestaurant.model.Restaurant;
import com.cgi.foodieapprestaurant.repository.RestaurantRepo;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class RestaurantServiceTest {

    @InjectMocks
    RestaurantServerImpl restaurantService;

    private Restaurant restaurant;
    private List<Restaurant> restaurantList;
    private Optional optional;

    @Mock
    RestaurantRepo restaurantRepo;


    @Before
    public void init(){
        MockitoAnnotations.openMocks(this);
        restaurant = new Restaurant();
        restaurant.setRestaurantId(101);
        restaurant.setAddress("FredrichStrasse 2");
        restaurant.setCategory("Bar");
        restaurant.setCity("Berlin");
        restaurant.setImage("image.com");
        restaurant.setUsername("Tamas");
        restaurant.setRestaurantName("West Bar Berlin");
        restaurant.setApprovalStatus(false);
        restaurant.addRating("Tamas",3);
        restaurant.setPhonenumber(123456);
    }

    @Test
    public void addRestaurantSuccessTest () throws Exception{
        when(restaurantRepo.save(restaurant)).thenReturn(restaurant);

        Restaurant restResult = restaurantService.addRestaurant(restaurant);
        assertEquals(restResult.getRestaurantId(), restaurant.getRestaurantId());
        verify(restaurantRepo, times(1)).save(restaurant);
    }

    @Test
    public void addRestaurantFailureTest(){
        Optional <Restaurant> restaurantOptional = Optional.of(restaurant);

        when(restaurantRepo.findById(101)).thenReturn(restaurantOptional);

        assertThrows(RestaurantIdAlreadyExistsException.class, () -> restaurantService.addRestaurant(restaurant));

        verify(restaurantRepo,times(1)).save(restaurant);
    }

    @Test
    public void deleteRestaurantThatExists() throws Exception{
        Optional <Restaurant> restaurantOptional = Optional.of(restaurant);
        when(restaurantRepo.findById(restaurant.getRestaurantId())).thenReturn(restaurantOptional);
        Boolean deletedRestaurant = restaurantService.deleteRestaurant(101);
        assertEquals(true, deletedRestaurant);
    }

    @Test
    public void deleteRestaurantThatNotExists() throws Exception{
        Optional <Restaurant> restaurantOptional = Optional.of(restaurant);
        when(restaurantRepo.findById(restaurant.getRestaurantId())).thenReturn(restaurantOptional);
        Boolean deletedRestaurant = restaurantService.deleteRestaurant(102);
        assertEquals(false, deletedRestaurant);
    }

    @Test
    public void givenGetAllRestaurantsThenShouldReturnListOfAllRestaurants() throws Exception {
        restaurantRepo.save(restaurant);
        when(restaurantRepo.findAll()).thenReturn(restaurantList);
        List<Restaurant> restaurantList1 = restaurantService.getRestaurants();
        assertEquals(restaurantList, restaurantList1);
        verify(restaurantRepo, times(1)).save(restaurant);
        verify(restaurantRepo, times(1)).findAll();
    }



}
