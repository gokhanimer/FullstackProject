package com.cgi.foodieapprestaurant.controller;

import com.cgi.foodieapprestaurant.exception.RestaurantIdAlreadyExistsException;
import com.cgi.foodieapprestaurant.exception.RestaurantIdNotFoundException;
import com.cgi.foodieapprestaurant.model.Restaurant;
import com.cgi.foodieapprestaurant.service.RestaurantService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;


@RunWith(SpringRunner.class)
@WebMvcTest
public class RestaurantControllerTest {

    @Autowired
    MockMvc mockMvc;

    private Restaurant restaurant;
    private List<Restaurant> restaurantList;

    @InjectMocks
    RestaurantController restaurantController;

    @MockBean
    RestaurantService restaurantService;



    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);

        mockMvc = MockMvcBuilders.standaloneSetup(restaurantController).build();

        restaurantList = new ArrayList<Restaurant>();
        restaurant = new Restaurant();
        restaurant.setRestaurantId(101);
        restaurant.setAddress("FredrichStrasse 2");
        restaurant.setCategory("Bar");
        restaurant.setCity("Berlin");
        restaurant.setImage("image.com");
        restaurant.setRestaurantName("West Bar Berlin");
        restaurant.setApprovalStatus(false);
        restaurant.addRating("Tamas",3);
        restaurant.setPhonenumber(123456);
    }

    @Test //WORKS
    public void addRestaurantSuccess() throws Exception{
        when(restaurantService.addRestaurant(restaurant)).thenReturn(restaurant);

        mockMvc.perform(MockMvcRequestBuilders.post("/restaurant/addRestaurant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(converttojson(restaurant)))
                .andExpect(MockMvcResultMatchers.status().isCreated());
    }

    @Test //WORKS
    public void addRestaurantFailure() throws Exception{
        when(restaurantService.addRestaurant(any())).thenThrow(RestaurantIdAlreadyExistsException.class);

        mockMvc.perform(MockMvcRequestBuilders.post("/restaurant/addRestaurant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(converttojson(restaurant)))
                .andExpect(MockMvcResultMatchers.status().isConflict())
                .andDo(MockMvcResultHandlers.print());
    }


    @Test //WORKS
    public void deleteRestaurantSuccess() throws Exception{
        when(restaurantService.deleteRestaurant(anyInt())).thenReturn(true);
        mockMvc.perform(
                        MockMvcRequestBuilders.delete("/restaurant/deleteRestaurant/101")
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(MockMvcResultHandlers.print());
    }

    @Test //WORKS
    public void deleteRestaurantFailure() throws Exception{
        when(restaurantService.deleteRestaurant(anyInt())).thenReturn(false);
        mockMvc.perform(
                        MockMvcRequestBuilders.delete("/restaurant/deleteRestaurant/102")
                )
                .andExpect(MockMvcResultMatchers.status().isNotFound())
                .andDo(MockMvcResultHandlers.print());
    }

    @Test //WORKS
    public void updateRestaurantSuccess() throws Exception{
        when(restaurantService.updateRestaurant(restaurant)).thenReturn(restaurant);

        mockMvc.perform(MockMvcRequestBuilders.put("/restaurant/update/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(converttojson(restaurant)))
                .andExpect(MockMvcResultMatchers.status().isAccepted());
    }

    @Test //WORKS
    public void updateRestaurantFailure() throws Exception{
        when(restaurantService.updateRestaurant(any())).thenThrow(RestaurantIdNotFoundException.class);

        mockMvc.perform(MockMvcRequestBuilders.put("/restaurant/update/")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(converttojson(restaurant)))
                .andExpect(MockMvcResultMatchers.status().isConflict());
    }

    @Test //WORKS
    public void getAllRestaurantsSuccess() throws Exception{
        mockMvc.perform(
                        MockMvcRequestBuilders.get("/restaurant/getRestaurant")
                )
                .andExpect(MockMvcResultMatchers.status().isOk());
    }

    public String converttojson (Object obj) throws JsonProcessingException {
        ObjectMapper objmap = new ObjectMapper();
        return objmap.writeValueAsString(obj);
    }

}
