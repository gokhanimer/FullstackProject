package com.cgi.foodieapprestaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodieappRestaurantApplicationTests {

    @Test
    void contextLoads() {
    }

}
