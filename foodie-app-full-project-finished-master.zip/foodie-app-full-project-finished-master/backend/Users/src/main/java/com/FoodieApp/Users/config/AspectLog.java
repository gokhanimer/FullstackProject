package com.FoodieApp.Users.config;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AspectLog {
	
	Logger logger=LoggerFactory.getLogger(AspectLog.class);
	
	@Pointcut("execution (* com.FoodieApp.Users.controller.UserController.registerUser(..))")
	public void addUser() {	
	}	
	@Pointcut("execution (* com.FoodieApp.Users.controller.UserController.deleteUser(..))")
	public void deleteUser() {
	}	
	@Pointcut("execution (* com.FoodieApp.Users.controller.UserController.updateUser(..))")
	public void updateUser() {	
	}
	@Pointcut("execution (* com.FoodieApp.Users.controller.UserController.getUsers(..))")
	public void viewUsers() {		
	}
	
	@Before("addUser()")
	public void addUserLog(JoinPoint jp) {
		logger.info("User is registered");
	}
	
	@After("deleteUser()")	
       public void deleteUserLog(JoinPoint jp) {
		logger.info("User is deleted");		
	}
	
	@After("viewUsers()")
	public void afterViewingUsers(JoinPoint jp) {
		System.out.println("Viewing all users");
	}

	@AfterReturning("updateUser()")
	public void afterUserUpdated() {
		logger.info("User is updated");
	}


	
	

}
