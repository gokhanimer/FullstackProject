package com.FoodieApp.Users.exception;

public class UserCredentialsAlreadyExists extends RuntimeException{
	
	private String message;
	public UserCredentialsAlreadyExists(String message)
	 {
		 super(message);
		 this.message = message;
	 }
	
	public UserCredentialsAlreadyExists() {
		
	}
}
