package com.FoodieApp.Users.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.FoodieApp.Users.exception.UserCredentialsAlreadyExists;
import com.FoodieApp.Users.exception.UserNotFound;
import com.FoodieApp.Users.model.User;
import com.FoodieApp.Users.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository repo;

	@Override
	public User registerUser(User user) throws UserCredentialsAlreadyExists{
		Optional<User> optUser = repo.findById(user.getUsername());
		if(optUser.isEmpty()) {
			repo.save(user);
			return user;
		} else throw new UserCredentialsAlreadyExists("Username already exists!");
	}

	@Override
	public boolean userLogin(User user) {
		User res = repo.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		if (res==null)
		return false;
		else
		return true;
	}

	@Override
	public boolean deleteUser(String username) throws UserNotFound{
		Optional<User> optUser = repo.findById(username);
		if(optUser.isPresent()) {
			repo.deleteById(username);
			return true;
		} else
		return false;
	}

	@Override
	public User updateUser(User user) throws UserNotFound {
		Optional<User> optUser = repo.findById(user.getUsername());
		if(optUser.isPresent()) {
			repo.save(user);
			return user;
		} else
		throw new UserNotFound("User not found");
	}

	@Override
	public List<User> getUsers() {
		return repo.findAll();
	}
}
