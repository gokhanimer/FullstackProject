package com.FoodieApp.Users.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.FoodieApp.Users.exception.UserCredentialsAlreadyExists;
import com.FoodieApp.Users.exception.UserNotFound;
import com.FoodieApp.Users.model.User;
import com.FoodieApp.Users.service.UserService;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserService service;
	
	@PostMapping("/register/addUser")
	public ResponseEntity<?> registerUser(@RequestBody User user) throws UserCredentialsAlreadyExists, Exception {
		User response;
		try{
		      response = service.registerUser(user);
		      return new ResponseEntity<User>(response, HttpStatus.CREATED);
		      
		   }catch(UserCredentialsAlreadyExists e){
		      return new ResponseEntity<String>(e.getMessage(), HttpStatus.CONFLICT);
		   }
	}
	@DeleteMapping("/register/deleteUser/{username}")
	public ResponseEntity<?> deleteUser(@PathVariable("username") String username) throws UserNotFound, Exception {
		boolean deleted = service.deleteUser(username);
		if (deleted)
			return new ResponseEntity<String>("User deleted!", HttpStatus.OK);
		else
			return new ResponseEntity<String>("User not found!", HttpStatus.NOT_FOUND);
		}
	
	@PutMapping("/register/updateUser")
	public ResponseEntity<?> updateUser(@RequestBody User user) throws Exception{
		User response;
		try{
			response = service.updateUser(user);
			return new ResponseEntity<User>(response, HttpStatus.ACCEPTED);
		}catch(UserNotFound e){
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	@GetMapping("/register/viewUsers")
	public ResponseEntity<?> getUsers() {
		List<User> users = service.getUsers();
		return new ResponseEntity<List<User>>(users, HttpStatus.OK);
	}
	
	@PostMapping("/login/authUser")
	public ResponseEntity<?> userLogin(@RequestBody User user) {
		boolean login = service.userLogin(user);
		if (login) {
			String jwt = generateToken(user);
			System.out.println(jwt);
			HashMap map = new HashMap();
			map.put("mytoken", jwt);
			return new ResponseEntity<HashMap>(map, HttpStatus.OK);
		} else
			return new ResponseEntity<String>("Invalid credentials", HttpStatus.UNAUTHORIZED);
	}
	String generateToken(User user) {
		
		return Jwts.builder()
				.setSubject(user.getUsername())
				.signWith(SignatureAlgorithm.HS256, "foodie")
				.compact();
	}
}
