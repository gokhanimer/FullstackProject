package com.FoodieApp.Users.service;

import java.util.List;

import com.FoodieApp.Users.exception.UserCredentialsAlreadyExists;
import com.FoodieApp.Users.exception.UserNotFound;
import com.FoodieApp.Users.model.User;

public interface UserService {

	public User registerUser(User user) throws UserCredentialsAlreadyExists;
	
	public boolean userLogin(User user);
	
	public boolean deleteUser(String username) throws UserNotFound;
	
	public User updateUser(User user) throws UserNotFound;
	
	public List<User> getUsers();
	
}
