package com.FoodieApp.Users.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.FoodieApp.Users.exception.UserCredentialsAlreadyExists;
import com.FoodieApp.Users.exception.UserNotFound;
import com.FoodieApp.Users.model.User;
import com.FoodieApp.Users.service.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@WebMvcTest
public class UserControllerTest {
	@Autowired
	private MockMvc mockMvc;

	private User user;
	private List<User> userList;

    @InjectMocks
    UserController userController;

    @MockBean
    UserService userService;

	@BeforeEach
	public void setUp() throws Exception {

		MockitoAnnotations.openMocks(this);

        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();

        userList = new ArrayList<User>();
        user = new User();
        user.setAddress("Adress");
        user.setCity("City");
        user.setFirstname("Firstname");
        user.setLastname("Lastname");
        user.setUsername("Username");
        user.setPassword("password");
        user.setPhonenumber(787878);
        user.setStatus("user");
        userList.add(user);
	}

	@Test
    public void addUserSuccess() throws Exception{
        when(userService.registerUser(user)).thenReturn(user);

        mockMvc.perform(post("/user/register/addUser")
                .contentType(MediaType.APPLICATION_JSON)
                .content(toJson(user)))
                .andExpect(MockMvcResultMatchers.status().isCreated());
    }

    @Test
    public void addUserFailure() throws Exception{
        when(userService.registerUser(any())).thenThrow(UserCredentialsAlreadyExists.class);

        mockMvc.perform(post("/user/register/addUser")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(toJson(user)))
                .andExpect(MockMvcResultMatchers.status().isConflict())
                .andDo(MockMvcResultHandlers.print());
    }
	@Test
	void deleteUserSuccess() throws Exception {
       when(userService.deleteUser(any())).thenReturn(true);

       mockMvc.perform(delete("/user/register/deleteUser/Username")
    		   	.contentType(MediaType.APPLICATION_JSON))
       			.andExpect(status().isOk())
       			.andDo(MockMvcResultHandlers.print());
	}

	@Test
	void deleteUserFailure() throws Exception{
		when(userService.deleteUser(any())).thenReturn(false);

	    mockMvc.perform(delete("/user/register/deleteUser/john123")
	    		.contentType(MediaType.APPLICATION_JSON))
	    		.andExpect(status().isNotFound())
	    		.andDo(MockMvcResultHandlers.print());
	}
	@Test
	void editUserSuccess() throws Exception{
		when(userService.updateUser(any())).thenReturn(user);
        mockMvc.perform(put("/user/register/updateUser")
        		.contentType(MediaType.APPLICATION_JSON)
        		.content(toJson(user)))
                .andExpect(status().isAccepted())
                .andDo(MockMvcResultHandlers.print());
    }
	@Test
	void editUserFail() throws Exception{

		when(userService.updateUser(any())).thenThrow(UserNotFound.class);
        mockMvc.perform(put("/user/register/updateUser")
        		.contentType(MediaType.APPLICATION_JSON)
        		.content(toJson(user)))
                .andExpect(status().isNotFound())
                .andDo(MockMvcResultHandlers.print());
	}

	@Test
	public void getAllUsersTest() throws Exception{
		mockMvc.perform(get("/user/register/viewUsers"))
		.andExpect(status().isOk());

	}
	public String toJson(Object obj) throws JsonProcessingException
	{
		ObjectMapper objmap=new ObjectMapper();
		String result=objmap.writeValueAsString(obj);

		return result;
	}

}
