package com.FoodieApp.Users.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.annotation.Rollback;

import com.FoodieApp.Users.exception.UserCredentialsAlreadyExists;
import com.FoodieApp.Users.exception.UserNotFound;
import com.FoodieApp.Users.model.User;
import com.FoodieApp.Users.repository.UserRepository;

public class UserServiceTest {

	@Mock
	private UserRepository repo;
	
	@InjectMocks
	private UserServiceImpl service;
	
	private User user;
	private List <User> users;
	
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
		users = new ArrayList<User>();
		user = new User("john123",
						"password" ,
						"John" ,
						"Stevens" ,
						645135216 , 
						"Stockholm",
						"Drottninggatan 17" ,
						"user");
		users.add(user);		
	}

	@Test
	public void addUserSuccess() throws UserCredentialsAlreadyExists {
		when(repo.save(user)).thenReturn(user);
		User res = service.registerUser(user);
		assertEquals(user.getUsername(), res.getUsername());		
		verify(repo,times(1)).save(user);
		verify(repo,times(1)).findById(any());
	}
	@Test
	public void addUserFailure() throws UserCredentialsAlreadyExists{
		when(repo.findById(any())).thenReturn(Optional.of(user));
		assertThrows(UserCredentialsAlreadyExists.class, 
			() -> service.registerUser(user));
	}
	
	@Test
	public void deleteUserSucces() throws Exception{
		Optional <User> userOpt = Optional.of(user);
		when(repo.findById(user.getUsername())).thenReturn(userOpt);
		Boolean deletedUser = service.deleteUser("john123");
		assertEquals(true, deletedUser);

	}
	@Test
	public void deleteUserFailure() throws UserNotFound{
		Optional <User> userOpt = Optional.of(user);
		when(repo.findById(user.getUsername())).thenReturn(userOpt);
		Boolean deletedUser = service.deleteUser("john1231");
		assertEquals(false, deletedUser);

	}
	@Test
	public void updateUserSucces(){
		Optional <User> userOpt = Optional.of(user);
		when(repo.findById(user.getUsername())).thenReturn(userOpt);
		User save = service.updateUser(user);		
		assertEquals(user.getUsername(), save.getUsername());		
		}
	
	@Test
	public void updateUserFailure() throws Exception{
		when(repo.findById(any())).thenReturn(null);
		assertThrows(Exception.class, 
			() -> service.updateUser(user));
		}
	
	@Test
	public void getUsersSucces() {
		when(repo.findAll()).thenReturn(users);
		
		assertEquals(users, service.getUsers());
		verify(repo,times(1)).findAll();

	}

}
