package com.cgi.transactions.service;

import com.cgi.transactions.model.Transaction;
import com.cgi.transactions.repository.TransactionRepo;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
public class TransactionServiceTest {

    @InjectMocks
    TransactionServiceImpl transactionService;

    private Transaction transaction;
    private List<Transaction> transactionList;
    private Optional optional;

    @Mock
    TransactionRepo transactionRepo;

    LocalDate date;

    @Before
    public void init() {
        MockitoAnnotations.openMocks(this);
        transaction = new Transaction();
        transaction.setTransId("1");
        transaction.setDishName(Collections.singletonList("food"));
        transaction.setDate(date);
        transaction.setStatus("ok");
        transaction.setPaymentMethod("visa");
        transaction.setTotalPrice(55.50);
        transaction.setUsername("user");
        transaction.setRestaurantId(1);

    }

    //Passes as expected
    @Test
    public void addTransactionSuccessTest () throws Exception {
        when(transactionRepo.save(transaction)).thenReturn(transaction);

        Transaction transResult = transactionService.postTransaction(transaction);
        assertEquals(transResult.getTransId(), transaction.getTransId());
        verify(transactionRepo, times(1)).save(transaction);
    }

    //Fails as expected
    @Test
    public void addTransactionFailTest() {
        Optional<Transaction> transactionOptional = Optional.of(transaction);

        when(transactionRepo.findById("1")).thenReturn(transactionOptional);

        assertThrows(Exception.class, () -> transactionService.postTransaction(transaction));

        verify(transactionRepo, times(1)).save(transaction);

    }

    //Passes as expected
    @Test
    public void deleteExistingTransaction() throws Exception{
        Optional <Transaction> transactionOptional = Optional.of(transaction);
        when(transactionRepo.findById(transaction.getTransId())).thenReturn(transactionOptional);
        boolean deletedTransaction = transactionService.deleteTransaction("1", transaction);
        assertEquals(true, deletedTransaction);
    }

    //Fails as expected
    @Test
    public void deleteNonExistingTransaction() throws Exception{
        Optional <Transaction> optionalTransaction = Optional.of(transaction);
        when(transactionRepo.findById(transaction.getTransId())).thenReturn(optionalTransaction);
        boolean deletedTransaction = transactionService.deleteTransaction("1", transaction);
        assertEquals(false, deletedTransaction);
    }

    //Passes as expected
    @Test
    public void shouldReturnAllTransactions() throws Exception {
        transactionRepo.save(transaction);
        when(transactionRepo.findAll()).thenReturn(transactionList);
        List<Transaction> transactionList1 = transactionService.getAllTransactions();
        assertEquals(transactionList, transactionList1);
        verify(transactionRepo, times(1)).save(transaction);
        verify(transactionRepo, times(1)).findAll();
    }

    //Passes as expected
    @Test
    public void shouldReturnTransactionByUsername() throws Exception {
        transactionRepo.save(transaction);

        when(transactionRepo.findByUsername(transaction.getUsername())).thenReturn(transactionList);
        List<Transaction> transactionList1 = transactionService.viewByUsername("user");
        assertEquals(transactionList, transactionList1);
        verify(transactionRepo, atLeastOnce()).findByUsername("user");
    }

    //Passes as expected
    @Test
    public void shouldReturnTransactionStatus() throws Exception {
        transactionRepo.save(transaction);

        when(transactionRepo.findByStatus(transaction.getStatus())).thenReturn(transactionList);
        List<Transaction> transactionList1 = transactionService.viewByStatus("ok");
        assertEquals(transactionList, transactionList1);
        verify(transactionRepo, atLeastOnce()).findByStatus("ok");
    }

    //Passes as expected
    @Test
    public void shouldReturnTransactionByRestaurantId() throws Exception {
        transactionRepo.save(transaction);

        when(transactionRepo.findByRestaurantId(transaction.getRestaurantId())).thenReturn(transactionList);
        List<Transaction> transactionList1 = transactionService.viewByRestaurantId(1);
        assertEquals(transactionList, transactionList1);
        verify(transactionRepo, atLeastOnce()).findByRestaurantId(1);
    }

    //Passes as expected
    @Test
    public void shouldReturnTransactionByDate() throws Exception {
        transactionRepo.save(transaction);

        when(transactionRepo.findByDate(transaction.getDate())).thenReturn(transactionList);
        List<Transaction> transactionList1 = transactionService.viewByDate(date);
        assertEquals(transactionList, transactionList1);
        verify(transactionRepo, atLeastOnce()).findByDate(date);
    }
}

