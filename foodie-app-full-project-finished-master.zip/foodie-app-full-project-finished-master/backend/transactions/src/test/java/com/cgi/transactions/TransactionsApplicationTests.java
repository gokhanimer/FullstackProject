package com.cgi.transactions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionsApplicationTests {

    //Passes as expected
    @Test
    void contextLoads() {
    }

}
