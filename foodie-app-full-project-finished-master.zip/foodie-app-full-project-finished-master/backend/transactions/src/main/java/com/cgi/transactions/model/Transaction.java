package com.cgi.transactions.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Document("foodie-transactions")
public class Transaction {

    @Id
    String transId;

    List<String> dishName;
    double totalPrice;

    String paymentMethod;

    int restaurantId;
    String username;

    @CreatedDate
    LocalDate date;

    String status;


    public Transaction() {

    }

    public Transaction(String transId, List<String> dishName, double totalPrice, String paymentMethod, String username, LocalDate date, String status, int restaurantId) {
        this.transId = transId;
        this.dishName = dishName;
        this.totalPrice = totalPrice;
        this.paymentMethod = paymentMethod;
        this.username = username;
        this.date = date;
        this.status = status;
        this.restaurantId = restaurantId;
    }

    public String getTransId() {

        return transId;
    }

    public void setTransId(String transId) {

        this.transId = transId;
    }

    public List<String> getDishName() {
        return dishName;
    }
    public void setDishName(List<String> dishName) {

        this.dishName = dishName;
    }

    public double getTotalPrice() {

        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {

        this.totalPrice = totalPrice;
    }

    public String getUsername() {

        return username;
    }

    public void setUsername(String username) {

        this.username = username;
    }

    public LocalDate getDate() {

        return date;
    }

    public void setDate(LocalDate date) {

        this.date = date;
    }

    public String getStatus() {

        return status;
    }

    public void setStatus(String status) {

        this.status = status;
    }

    public String getPaymentMethod() {

        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {

        this.paymentMethod = paymentMethod;
    }

    public int getRestaurantId() {

        return restaurantId;
    }

    public void setRestaurantId(int restaurantId) {

        this.restaurantId = restaurantId;
    }

    @Override
    public String toString() {
        return "Transaction [" +
                "transId=" + transId +
                ", dishName=" + dishName +
                ", totalPrice=" + totalPrice +
                ", paymentMethod=" + paymentMethod +
                ", username=" + username +
                ", date=" + date +
                ", status=" + status +
                ", restaurantId=" + restaurantId +
                "]";
    }
}
