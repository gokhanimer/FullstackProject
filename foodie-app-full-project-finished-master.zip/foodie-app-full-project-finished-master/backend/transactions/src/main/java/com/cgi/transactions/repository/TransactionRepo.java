package com.cgi.transactions.repository;

import com.cgi.transactions.model.Transaction;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TransactionRepo extends MongoRepository<Transaction, String> {


    List<Transaction> findByStatus(String status);

    List<Transaction> findByRestaurantId(int restaurantId);

    List<Transaction> findByDate(LocalDate date);

    List<Transaction> findByUsername(String username);

}
