package com.cgi.transactions.controller;

import com.cgi.transactions.model.Transaction;
import com.cgi.transactions.service.TransactionService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/transaction")
public class TransactionController {

    @Autowired
    TransactionService transactionService;

    @ApiOperation("New transaction")
    @PostMapping("/addTransaction")
    public ResponseEntity<?> addTransaction(@RequestBody Transaction newTransaction) throws Exception {
        Transaction result = transactionService.postTransaction(newTransaction);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    @GetMapping("/viewAllTransactions")
    public ResponseEntity<?> getTransactions() {
        List<Transaction> transactions = transactionService.getAllTransactions();
        return new ResponseEntity<>(transactions, HttpStatus.OK);
    }

    @DeleteMapping("/deleteTransaction/{transId}")
    public ResponseEntity<?> removeTransaction(@PathVariable("transId") String transId, Transaction transaction) {
        boolean result = transactionService.deleteTransaction(transId, transaction);
        if (result) {
            return new ResponseEntity<>("Transaction has been deleted", HttpStatus.OK);
        } else
            return new ResponseEntity<>("Transaction not found", HttpStatus.NOT_FOUND);
    }

    @PutMapping("/updateTransaction/{transId}")
    public ResponseEntity<?> updateTransaction(@PathVariable String transId, @RequestBody Transaction transaction) {
        try {
            transactionService.updateTransaction(transId, transaction);
            return new ResponseEntity<>("Transaction has been updated", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/viewTransactionByUsername/{username}")
    public ResponseEntity<?> viewByUsername(@PathVariable String username) {
        List<Transaction> transactions = transactionService.viewByUsername(username);
        return new ResponseEntity<>(transactions, HttpStatus.OK);

    }

    @GetMapping("/viewTransactionByStatus/{status}")
    public ResponseEntity<?> viewTransactionByStatus(@PathVariable String status) {
        List<Transaction> transactions = transactionService.viewByStatus(status);
        return new ResponseEntity<>(transactions, HttpStatus.OK);

    }

    @GetMapping("/viewTransactionByDate/{date}")
    public ResponseEntity<?> viewTransactionByDate(@PathVariable LocalDate date) {
        List<Transaction> transactionDate = transactionService.viewByDate(date);
        return new ResponseEntity<>(transactionDate, HttpStatus.OK);
    }

    @GetMapping("/viewTransactionByRestaurantId/{restaurantId}")
    public ResponseEntity<?> viewTransactionByRestaurantId(@PathVariable int restaurantId) {
        try {
            return new ResponseEntity<>(transactionService.viewByRestaurantId(restaurantId), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}


