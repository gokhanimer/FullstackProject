package com.cgi.transactions.service;


import com.cgi.transactions.model.Transaction;
import com.cgi.transactions.repository.TransactionRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class TransactionServiceImpl implements TransactionService {

    @Autowired
    TransactionRepo transactionRepo;


    @Override
    public Transaction postTransaction(Transaction newTransaction) throws Exception {
        Optional<Transaction> optionalTrans = transactionRepo.findById(newTransaction.getTransId());
        if (optionalTrans.isEmpty()) {
            transactionRepo.save(newTransaction);
            return newTransaction;
        } else {
            throw new Exception("Transaction already exists");
        }
    }

    @Override
    public List<Transaction> getAllTransactions() {

        return transactionRepo.findAll();
    }

    @Override
    public boolean deleteTransaction(String transId, Transaction transaction) {
        Optional<Transaction> optionalTransaction1 = transactionRepo.findById(transId);
            if (optionalTransaction1.isPresent()) {
                transactionRepo.deleteById(transId);
                return true;
            } else {
                return false;
            }
        }


            @Override
            public Transaction updateTransaction(String transId, Transaction updateTrans) {
                Optional<Transaction> optionalTransaction2 = transactionRepo.findById(updateTrans.getTransId());
                if (optionalTransaction2.isPresent()) {
                    transactionRepo.save(updateTrans);
                    return updateTrans;
                } else {
                    return null;
                }
            }

                    @Override
                    public List<Transaction> viewByUsername(String username) {
                        return transactionRepo.findByUsername(username);
                    }

                   @Override
                    public List<Transaction> viewByDate(LocalDate date){

                            return transactionRepo.findByDate(date);
                    }

                    @Override
                    public List<Transaction> viewByStatus(String status){
                        return transactionRepo.findByStatus(status);
                    }

                    @Override
                    public List<Transaction> viewByRestaurantId (int restaurantId) {
                        return transactionRepo.findByRestaurantId(restaurantId);
                    }

                }


