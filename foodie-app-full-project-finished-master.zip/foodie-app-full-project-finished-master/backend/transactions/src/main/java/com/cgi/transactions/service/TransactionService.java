package com.cgi.transactions.service;

import com.cgi.transactions.model.Transaction;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

public interface TransactionService {

    Transaction postTransaction(Transaction newTransaction) throws Exception;

    List<Transaction> getAllTransactions();

    boolean deleteTransaction(String transId, Transaction transaction);

    Transaction updateTransaction(String transId, Transaction transaction);

    List<Transaction> viewByUsername(String username);

    List<Transaction> viewByDate(LocalDate date);

    List<Transaction> viewByStatus(String status);

    List<Transaction> viewByRestaurantId(int restaurantId);

}
