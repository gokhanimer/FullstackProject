package com.cgi.transactions.config;

import com.cgi.transactions.model.Transaction;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AspectLog {

    Logger log = LoggerFactory.getLogger(AspectLog.class);

    @Before("execution (* com.cgi.transactions.controller.TransactionController.addTransaction(..))")
    public void beforeAddTransactionLog(JoinPoint jP) {
        log.info("Before adding Transaction");
    }

    @Before("execution (* com.cgi.transactions..controller.TransactionController.removeTransaction(..))")
    public void beforeRemoveTransactionLog(JoinPoint jP) {
        log.warn("Before removing transaction");
    }

    @Before("execution (* com.cgi.transactions.controller.TransactionController.updateTransaction(..))")
    public void beforeUpdateTransactionLog(JoinPoint jP) {
        log.info("Before updating transaction");
    }

    @Around("execution (* com.cgi.transactions.controller.TransactionController.addTransaction(..))")
    public Object addNewTransactionLog(ProceedingJoinPoint pB) throws Throwable {
        Object object = pB.proceed();
        try {
            ResponseEntity responseEntity = (ResponseEntity) object;

            Transaction transactionObject = (Transaction) responseEntity.getBody();
            log.info("Transaction ID " + transactionObject.getTransId() + " is being stored");
        } catch (Exception e) {
            log.warn(String.valueOf(e));
        }
        return object;
    }

    @After("execution (* com.cgi.transactions.controller.TransactionController.addTransaction(..))")
    public void afterPostedTransaction(JoinPoint jP) {
        log.info("New transaction has been added");
    }

    @After("execution (* com.cgi.transactions.controller.TransactionController.updateTransaction(..))")
    public void afterUpdatedTransaction(JoinPoint jP) {
        log.info("Transaction has now been updated");
    }

    @After("execution (* com.cgi.transactions.controller.TransactionController.removeTransaction(..))")
    public void afterDeletedTransaction(JoinPoint jP) {
        log.info("Transaction has now been deleted");
    }
}
